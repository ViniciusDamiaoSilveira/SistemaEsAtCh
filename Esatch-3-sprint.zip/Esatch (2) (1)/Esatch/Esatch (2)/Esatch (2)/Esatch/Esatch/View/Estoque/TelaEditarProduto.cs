﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Estoque
{
    public partial class TelaEditarProduto : Form
    {
        string cpf;
        string id;
        public TelaEditarProduto(string id)
        {
            this.id = id;
            InitializeComponent();
        }

        Controller.EstoqueController controlador = new Controller.EstoqueController();

        private void TelaEditarProduto_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void botao_editar_Click(object sender, EventArgs e)
        {
            if(txt_codigo.Text == "" || txt_fornecedor.Text == "" || txt_local.Text == "" || txt_nome.Text == "" || txt_quantidade.Text == "" || txt_status.Text == "")
            {
                MessageBox.Show("Por favor, preencha todos os campos", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                controlador.AtualizarProduto(id, txt_codigo.Text, txt_nome.Text, txt_quantidade.Text, txt_status.Text,
                txt_local.Text, txt_fornecedor.Text);
                MessageBox.Show("Produto editado com sucesso", "Editado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TelaInicial telainicial = new TelaInicial(cpf);
                telainicial.Show();
                this.Hide();
            }
           
        }

        private void TelaEditarProduto_Load(object sender, EventArgs e) {
            List<Model.Estoque> lista = controlador.MostrarProdutoID(id);
            foreach (Model.Estoque estoque in lista) {
                txt_codigo.Text = estoque.Codigo;
                txt_fornecedor.Text = estoque.Vendedor;
                txt_local.Text = estoque.Local;
                txt_nome.Text = estoque.Nome;
                txt_quantidade.Text = estoque.Quantidade;
                txt_status.Text = estoque.Status;
            }
        }

        private void icone_voltar_Click(object sender, EventArgs e) {
            TelaInicial telainicial = new TelaInicial(cpf);
            telainicial.Show();
            this.Hide();
        }
    }
}
