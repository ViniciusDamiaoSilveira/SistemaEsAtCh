﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Chamado
{
    public partial class TelaInicio : Form
    {
        string cpf;
        public TelaInicio(string cpf)
        {
            this.cpf = cpf;
            InitializeComponent();
        }

        

        private void TelaInicio_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void TelaChamado(object sender, EventArgs e) {
            View.Chamado.TelaEnviarChamado telachamado = new TelaEnviarChamado(cpf);
            telachamado.Show();
            this.Hide();
        }

        private void Icone_voltar_Click(object sender, EventArgs e) {
            TelaSistemas telainicial = new TelaSistemas(cpf);
            telainicial.Show();
            this.Hide();
        }

        private void Botao_visualizar_chamado_Click(object sender, EventArgs e) {
            TelaVerChamados telaverchamados = new TelaVerChamados(cpf);
            telaverchamados.Show();
            this.Hide();
        }
    }
}
