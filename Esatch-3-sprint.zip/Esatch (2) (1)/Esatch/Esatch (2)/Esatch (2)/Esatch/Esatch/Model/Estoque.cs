﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;

namespace Esatch.Model
{
    class Estoque
    {

        static string dados_conexao = "Server=10.87.100.6;Database=esatch;User id = aluno; Password=Senai1234";
        private string codigo, nome, quantidade, status, local, vendedor, id;

        public Estoque(string codigo, string nome, string quantidade, string status, string local, string vendedor, string id) {
            this.codigo = codigo;
            this.nome = nome;
            this.quantidade = quantidade;
            this.status = status;
            this.local = local;
            this.vendedor = vendedor;
            this.id = id;
        }

        public string Codigo { get => codigo; set => codigo = value; }
        public string Nome { get => nome; set => nome = value; }
        public string Quantidade { get => quantidade; set => quantidade = value; }
        public string Status { get => status; set => status = value; }
        public string Local { get => local; set => local = value; }
        public string Vendedor { get => vendedor; set => vendedor = value; }
        public string Id { get => id; set => id = value; }



        public static List<Estoque> MostrarEstoque() {
            //Objeto da lista de estoque
            List<Estoque> lista = new List<Estoque>();

            //Objeto da conexão
            MySqlConnection con = new MySqlConnection(dados_conexao);

            try {
                //Abrir conexão
                con.Open();
                MySqlCommand comando = new MySqlCommand("SELECT * FROM estoques", con);

                //Objeto do leitor
                MySqlDataReader leitor = comando.ExecuteReader();

                //Leitura dos dados 
                while (leitor.Read()) {
                    Estoque estoque = new Estoque(
                    leitor["codigo_MP"].ToString(),
                    leitor["nome_MP"].ToString(),
                    leitor["quantidade_MP"].ToString(),
                    leitor["status_MP"].ToString(),
                    leitor["local_MP"].ToString(),
                    leitor["vendedor_MP"].ToString(),
                    leitor["ID_MP"].ToString());


                    lista.Add(estoque);
                }

                //Fechar conexão
                con.Close();
                return lista;

            } catch (Exception ex) {
                return null;
            }
        }

        public static string AdicionarProduto(string codigo, string nome, string quantidade, string status, string local, string vendedor) {
            //Objeto da conexão
            MySqlConnection con = new MySqlConnection(dados_conexao);

            try {
                //Abrir conexão
                con.Open();

                //Objeto do comando sql
                MySqlCommand comando = new MySqlCommand("INSERT INTO estoques(codigo_MP, nome_MP, quantidade_MP, status_MP, local_MP, " +
                    "vendedor_MP) VALUES" +
                    " (@codigo, @nome_MP, @quantidade_MP, @status_MP, @local_MP, " +
                    " @vendedor_MP)", con);


                //Adicionando valores para as variáveis
                comando.Parameters.AddWithValue("@codigo", codigo);
                comando.Parameters.AddWithValue("@nome_MP", nome);
                comando.Parameters.AddWithValue("@quantidade_MP", quantidade);
                comando.Parameters.AddWithValue("@status_MP", status);
                comando.Parameters.AddWithValue("@local_MP", local);
                comando.Parameters.AddWithValue("@vendedor_MP", vendedor);
                comando.ExecuteNonQuery();

                //Fechar conexão
                con.Close();

                return "DEU CERTO";

            } catch (Exception ex) {
                return ex.ToString();
            }

        }

        public static List<Estoque> MostrarProdutoID(string id) {
            //Objeto da Lista
            List<Estoque> lista = new List<Estoque>();

            //Objeto da conexão
            MySqlConnection con = new MySqlConnection(dados_conexao);

            try {
                //Abrir conexão
                con.Open();
                MySqlCommand comando = new MySqlCommand("SELECT * FROM estoques WHERE ID_MP = @id", con);


                comando.Parameters.AddWithValue("@id", id);

                MySqlDataReader leitor = comando.ExecuteReader();

                while (leitor.Read()) {

                    Estoque estoque = new Estoque(
                    leitor["codigo_MP"].ToString(),
                    leitor["nome_MP"].ToString(),
                    leitor["quantidade_MP"].ToString(),
                    leitor["status_MP"].ToString(),
                    leitor["local_MP"].ToString(),
                    leitor["vendedor_MP"].ToString(),
                    leitor["ID_MP"].ToString());

                    lista.Add(estoque);

                }


                con.Close();
                return lista;

            } catch (Exception ex) {
                return null;
            }

        }

        public static string VerificarProduto(string id) {
            //Objeto da conexão
            MySqlConnection con = new MySqlConnection(dados_conexao);

            string status;

            try {
                //Abrir conexão
                con.Open();

                //Objeto do comando sql
                MySqlCommand comando = new MySqlCommand("SELECT * FROM estoques WHERE ID_MP = @id", con);

                //Adicionando valores para as variáveis
                comando.Parameters.AddWithValue("@id", id);

                //Objeto do leitor
                MySqlDataReader leitor = comando.ExecuteReader();

                //Verificar se existe no banco
                if (leitor.HasRows) {
                    status = "EXISTE";
                } else {
                    status = "FALSO";
                }

                //Fechar conexão
                con.Close();
                return status;

            } catch (Exception ex) {
                return ex.ToString();
            }

        }


        public static string AtualizarProduto(string id, string codigo, string nome, string quantidade, string status, string local, string vendedor) {
            //Objeto da conexão
            MySqlConnection con = new MySqlConnection(dados_conexao);

            try {
                //Abrir conexão
                con.Open();

                //Objeto do comando sql
                MySqlCommand comando = new MySqlCommand("UPDATE estoques SET codigo_MP = @codigo," +
                   " nome_MP = @nome, quantidade_MP = @quanti, status_MP = @status, local_MP = @local," +
                   "vendedor_MP = @vendedor WHERE ID_MP = @id", con);


                //Adicionando valores para as variáveis
                comando.Parameters.AddWithValue("id", id);
                comando.Parameters.AddWithValue("@codigo", codigo);
                comando.Parameters.AddWithValue("@nome", nome);
                comando.Parameters.AddWithValue("@quanti", quantidade);
                comando.Parameters.AddWithValue("@status", status);
                comando.Parameters.AddWithValue("@local", local);
                comando.Parameters.AddWithValue("@vendedor", vendedor);
                comando.ExecuteNonQuery();

                //Fechar conexão
                con.Close();
                return "DEU CERTO";

            } catch (Exception ex) {
                return ex.ToString();
            }

        }

    }
}
