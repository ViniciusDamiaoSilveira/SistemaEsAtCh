﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Admiministrador
{
    public partial class TelaCadastrarUsuario : Form
    {
        public TelaCadastrarUsuario() {
            InitializeComponent();
        }

        Controller.AdministradorController controlador = new Controller.AdministradorController();

        private void botao_cadastrar_Click(object sender, EventArgs e) {
            controlador.CadastrarUsuario(txt_cpf.Text, txt_senha.Text);
        }

        private void Icone_voltar_Click(object sender, EventArgs e)
        {
            TelaInicial telainicial = new TelaInicial();
            telainicial.Show();
            this.Hide();
        }
    }
}
