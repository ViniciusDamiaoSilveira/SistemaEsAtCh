﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Estoque
{
    public partial class TelaAdicionarProduto : Form
    {
        string cpf;
        public TelaAdicionarProduto(string cpf)
        {
            this.cpf = cpf;
            InitializeComponent();
        }

        Controller.EstoqueController controlador = new Controller.EstoqueController();

          

        private void FecharPrograma(object sender, FormClosedEventArgs e)
        {
            Application.Exit();

        }

        private void Botao_adicionar_Click(object sender, EventArgs e) {
            if (txt_codigo.Text == "" || txt_nome.Text == "" || txt_quantidade.Text == "" || txt_status.Text == "" ||
               txt_local.Text == "" || txt_fornecedor.Text == "") {
                MessageBox.Show("Por favor, preencha todos os campos.", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else {
                controlador.AdicionarEstoque(txt_codigo.Text, txt_nome.Text, txt_quantidade.Text, txt_status.Text, txt_local.Text, txt_fornecedor.Text);
                MessageBox.Show("Produto adicionado ao estoque com sucesso.", "Adicionado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TelaInicial telainicial = new TelaInicial(cpf);
                telainicial.Show();
                this.Hide();
            }
        }

        private void icone_voltar_Click(object sender, EventArgs e) {
            TelaInicial telainicial = new TelaInicial(cpf);
            telainicial.Show();
            this.Hide();
        }

        
    }
}
