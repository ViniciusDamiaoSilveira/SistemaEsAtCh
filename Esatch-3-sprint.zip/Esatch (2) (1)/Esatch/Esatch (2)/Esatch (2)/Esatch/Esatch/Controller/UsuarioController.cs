﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Esatch.Controller
{
    class UsuarioController
    {
        internal string EntrarUsuario(string cpf, string senha) {
            string statusLogin = Model.Usuario.EntrarUsuario(cpf, admin.Criptografar(senha));
            return statusLogin;
        }

        AdministradorController admin = new AdministradorController();
    }
}
