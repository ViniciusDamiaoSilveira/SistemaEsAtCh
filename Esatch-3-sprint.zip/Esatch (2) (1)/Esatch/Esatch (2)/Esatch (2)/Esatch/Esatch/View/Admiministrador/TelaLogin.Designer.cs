﻿
namespace Esatch.View.Admiministrador
{
    partial class TelaLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaLogin));
            this.botao_entrar = new System.Windows.Forms.Button();
            this.txt_codigo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.icone_voltar = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.icone_voltar)).BeginInit();
            this.SuspendLayout();
            // 
            // botao_entrar
            // 
            this.botao_entrar.BackColor = System.Drawing.Color.Orange;
            this.botao_entrar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.botao_entrar.Font = new System.Drawing.Font("Franklin Gothic Heavy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.botao_entrar.ForeColor = System.Drawing.Color.White;
            this.botao_entrar.Location = new System.Drawing.Point(654, 521);
            this.botao_entrar.Name = "botao_entrar";
            this.botao_entrar.Size = new System.Drawing.Size(115, 35);
            this.botao_entrar.TabIndex = 18;
            this.botao_entrar.Text = "Entrar";
            this.botao_entrar.UseVisualStyleBackColor = false;
            this.botao_entrar.Click += new System.EventHandler(this.botao_entrar_Click);
            // 
            // txt_codigo
            // 
            this.txt_codigo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_codigo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txt_codigo.Location = new System.Drawing.Point(230, 435);
            this.txt_codigo.Name = "txt_codigo";
            this.txt_codigo.Size = new System.Drawing.Size(539, 29);
            this.txt_codigo.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label3.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label3.Location = new System.Drawing.Point(223, 400);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 34);
            this.label3.TabIndex = 16;
            this.label3.Text = "Código";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial", 39.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(133)))), ((int)(((byte)(36)))));
            this.label2.Location = new System.Drawing.Point(238, 201);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(387, 62);
            this.label2.TabIndex = 15;
            this.label2.Text = "Administrador";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(133)))), ((int)(((byte)(36)))));
            this.label1.Location = new System.Drawing.Point(247, 164);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(506, 44);
            this.label1.TabIndex = 14;
            this.label1.Text = "Entre com o seu código de ";
            // 
            // icone_voltar
            // 
            this.icone_voltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.icone_voltar.Image = ((System.Drawing.Image)(resources.GetObject("icone_voltar.Image")));
            this.icone_voltar.Location = new System.Drawing.Point(10, 10);
            this.icone_voltar.Name = "icone_voltar";
            this.icone_voltar.Size = new System.Drawing.Size(32, 32);
            this.icone_voltar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.icone_voltar.TabIndex = 40;
            this.icone_voltar.TabStop = false;
            this.icone_voltar.Click += new System.EventHandler(this.icone_voltar_Click);
            // 
            // TelaLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(984, 861);
            this.Controls.Add(this.icone_voltar);
            this.Controls.Add(this.botao_entrar);
            this.Controls.Add(this.txt_codigo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.Name = "TelaLogin";
            this.Text = "TelaLogin";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.TelaLogin_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.icone_voltar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button botao_entrar;
        private System.Windows.Forms.TextBox txt_codigo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox icone_voltar;
    }
}