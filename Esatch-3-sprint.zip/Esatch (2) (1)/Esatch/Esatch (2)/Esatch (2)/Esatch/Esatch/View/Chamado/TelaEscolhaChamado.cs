﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Chamado
{
    public partial class TelaEscolhaChamado : Form
    {
        string cpf;
        public TelaEscolhaChamado(string cpf)
        {
            this.cpf = cpf;
            InitializeComponent();
        }

        Controller.ChamadoController controlador = new Controller.ChamadoController();

        private void botao_mostrar_Click_1(object sender, EventArgs e)
        {
            string status = controlador.VerificarChamado(Txt_codigo.Text, cpf);
            if (status == "EXISTE")
            {
                TelaClassificar telaclassificar = new TelaClassificar(Txt_codigo.Text, cpf);
                telaclassificar.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Código do chamado inválido ou o chamado já foi fechado, tente novamente.", "Código Errado", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void icone_voltar_Click_1(object sender, EventArgs e)
        {
            TelaInicio telainicio = new TelaInicio(cpf);
            telainicio.Show();
            this.Hide();
        }
    }
}
