﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AplicativoDesktop
{
    public partial class Tela_Login_ADM : Form
    {
        private Form1 form1;

        MySqlConnection conexao;
        string dados_conexao = "datasource=ESN509VMYSQL;username=aluno;password=Senai1234;database=atches";

        public Tela_Login_ADM(Form1 form1)
        {
            InitializeComponent();
            this.form1 = form1;
           
        }
       
        

        private void voltar_tela_inicial_Click(object sender, EventArgs e)
        {
            this.form1.Show();
            this.Close();
        }

        private void botao_entrar_Click(object sender, EventArgs e)
        {
            conexao = new MySqlConnection(dados_conexao);
            //Try Catch para usar a conexão com o banco
            try
            {
                //Abrir a conexão
                conexao.Open();

                //Utilizar o comando para verificação do login do usuário
                MySqlCommand comando = new MySqlCommand("SELECT * FROM adm WHERE codigo = @codigo AND senha = @senha", conexao);
                comando.Parameters.AddWithValue("@codigo", txt_codigo.Text);
                comando.Parameters.AddWithValue("@senha", txt_senha_adm.Text);

                //Verifica se existe no banco
                var resultado = comando.ExecuteScalar();

                if (resultado != null)
                {
                    Tela_Cadastro tela_cadastro = new Tela_Cadastro();
                    tela_cadastro.Show();
                    this.Visible = false;
                }
                else
                {
                    MessageBox.Show("Usuário ou Senha inválidos", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

            } catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            } finally
            {
                conexao.Close();
            }
        }
    }
}
