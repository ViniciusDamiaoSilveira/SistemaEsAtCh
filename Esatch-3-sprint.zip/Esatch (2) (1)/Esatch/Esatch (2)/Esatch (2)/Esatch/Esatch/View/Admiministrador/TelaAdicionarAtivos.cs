﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Admiministrador
{
    public partial class TelaAdicionarAtivos : Form
    {
        public TelaAdicionarAtivos()
        {
            InitializeComponent();
        }

        Controller.AtivoController controlador = new Controller.AtivoController();

        private void Botao_adicionar_Click(object sender, EventArgs e)
        {
            if(Txt_status.Text == "" || Txt_hardwareID.Text == "" || Txt_departamento.Text == "")
            {
                MessageBox.Show("Por favor, preencha todos os campos.", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                controlador.AdicionarAtivos(Txt_hardwareID.Text, Txt_departamento.Text, Txt_status.Text);
                MessageBox.Show("Ativo adicionado com sucesso!", "Adicionado", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void TelaAdicionarAtivos_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void Icone_voltar_Click(object sender, EventArgs e)
        {
            TelaAtivosInicial telainicial = new TelaAtivosInicial();
            telainicial.Show();
            this.Hide();
        }
    }
}
