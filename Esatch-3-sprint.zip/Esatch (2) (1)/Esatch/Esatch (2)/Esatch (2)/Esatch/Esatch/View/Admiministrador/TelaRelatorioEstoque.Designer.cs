﻿
namespace Esatch.View.Admiministrador
{
    partial class TelaRelatorioEstoque
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaRelatorioEstoque));
            this.list_relatorio = new System.Windows.Forms.ListView();
            this.Codigo = new System.Windows.Forms.ColumnHeader();
            this.Nome = new System.Windows.Forms.ColumnHeader();
            this.CPF = new System.Windows.Forms.ColumnHeader();
            this.Departamento = new System.Windows.Forms.ColumnHeader();
            this.icone_atualizar = new System.Windows.Forms.PictureBox();
            this.Botao_visualizar = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Icone_voltar = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.icone_atualizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Icone_voltar)).BeginInit();
            this.SuspendLayout();
            // 
            // list_relatorio
            // 
            this.list_relatorio.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.list_relatorio.Alignment = System.Windows.Forms.ListViewAlignment.Default;
            this.list_relatorio.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.list_relatorio.BackColor = System.Drawing.Color.Gainsboro;
            this.list_relatorio.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Codigo,
            this.Nome,
            this.CPF,
            this.Departamento});
            this.list_relatorio.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.list_relatorio.ForeColor = System.Drawing.Color.Black;
            this.list_relatorio.GridLines = true;
            this.list_relatorio.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.list_relatorio.HideSelection = false;
            this.list_relatorio.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.list_relatorio.Location = new System.Drawing.Point(73, 225);
            this.list_relatorio.Name = "list_relatorio";
            this.list_relatorio.Size = new System.Drawing.Size(854, 533);
            this.list_relatorio.TabIndex = 85;
            this.list_relatorio.UseCompatibleStateImageBehavior = false;
            this.list_relatorio.View = System.Windows.Forms.View.Details;
            // 
            // Codigo
            // 
            this.Codigo.Text = "Codigo";
            this.Codigo.Width = 100;
            // 
            // Nome
            // 
            this.Nome.Text = "Nome";
            this.Nome.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Nome.Width = 300;
            // 
            // CPF
            // 
            this.CPF.Text = "CPF";
            this.CPF.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.CPF.Width = 200;
            // 
            // Departamento
            // 
            this.Departamento.Text = "Departamento";
            this.Departamento.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Departamento.Width = 250;
            // 
            // icone_atualizar
            // 
            this.icone_atualizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.icone_atualizar.Image = ((System.Drawing.Image)(resources.GetObject("icone_atualizar.Image")));
            this.icone_atualizar.Location = new System.Drawing.Point(933, 726);
            this.icone_atualizar.Name = "icone_atualizar";
            this.icone_atualizar.Size = new System.Drawing.Size(32, 32);
            this.icone_atualizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.icone_atualizar.TabIndex = 89;
            this.icone_atualizar.TabStop = false;
            // 
            // Botao_visualizar
            // 
            this.Botao_visualizar.BackColor = System.Drawing.Color.Orange;
            this.Botao_visualizar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Botao_visualizar.Font = new System.Drawing.Font("Franklin Gothic Heavy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Botao_visualizar.ForeColor = System.Drawing.Color.White;
            this.Botao_visualizar.Location = new System.Drawing.Point(399, 799);
            this.Botao_visualizar.Name = "Botao_visualizar";
            this.Botao_visualizar.Size = new System.Drawing.Size(242, 35);
            this.Botao_visualizar.TabIndex = 84;
            this.Botao_visualizar.Text = "Relatório";
            this.Botao_visualizar.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(458, 33);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(106, 78);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 88;
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.Orange;
            this.label6.Location = new System.Drawing.Point(248, 147);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(504, 37);
            this.label6.TabIndex = 87;
            this.label6.Text = "Visualizar relatórios de estoque";
            // 
            // Icone_voltar
            // 
            this.Icone_voltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Icone_voltar.Image = ((System.Drawing.Image)(resources.GetObject("Icone_voltar.Image")));
            this.Icone_voltar.Location = new System.Drawing.Point(19, 23);
            this.Icone_voltar.Name = "Icone_voltar";
            this.Icone_voltar.Size = new System.Drawing.Size(32, 32);
            this.Icone_voltar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Icone_voltar.TabIndex = 86;
            this.Icone_voltar.TabStop = false;
            // 
            // TelaRelatorioEstoque
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(984, 861);
            this.Controls.Add(this.list_relatorio);
            this.Controls.Add(this.icone_atualizar);
            this.Controls.Add(this.Botao_visualizar);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Icone_voltar);
            this.Name = "TelaRelatorioEstoque";
            this.Text = "TelaRelatorioEstoque";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.TelaRelatorioEstoque_FormClosed);
            this.Load += new System.EventHandler(this.TelaRelatorioEstoque_Load);
            ((System.ComponentModel.ISupportInitialize)(this.icone_atualizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Icone_voltar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView list_relatorio;
        private System.Windows.Forms.ColumnHeader Codigo;
        private System.Windows.Forms.ColumnHeader Nome;
        private System.Windows.Forms.ColumnHeader CPF;
        private System.Windows.Forms.ColumnHeader Departamento;
        private System.Windows.Forms.PictureBox icone_atualizar;
        private System.Windows.Forms.Button Botao_visualizar;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox Icone_voltar;
    }
}