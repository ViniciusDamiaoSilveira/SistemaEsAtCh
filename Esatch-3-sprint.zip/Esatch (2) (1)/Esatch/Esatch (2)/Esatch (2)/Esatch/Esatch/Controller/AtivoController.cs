﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Esatch.Controller
{
    class AtivoController
    {
        internal List<Model.Ativo> ListarAtivos()
        {
            return Model.Ativo.ListarAtivos();
        }

        internal void AdicionarAtivos(string hardwareID, string departamento, string status)
        {
            Model.Ativo.AdicionarAtivos(hardwareID, departamento, status);
        }

        internal string VerificarAtivos(string id)
        {
            string ativo = Model.Ativo.VerificarAtivos(id);
            return ativo;
        }

        internal void AtualizarAtivo(string id, string hardwareID, string departamento, string status)
        {
            Model.Ativo.AtualizarAtivo(id, hardwareID, departamento, status);
        }
    }
}
