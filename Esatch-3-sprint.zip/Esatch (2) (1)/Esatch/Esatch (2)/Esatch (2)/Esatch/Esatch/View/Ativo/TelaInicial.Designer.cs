﻿
namespace Esatch.View.Ativo
{
    partial class TelaInicial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaInicial));
            this.Botao_relatorio = new System.Windows.Forms.Button();
            this.List_ativos = new System.Windows.Forms.ListView();
            this.ID = new System.Windows.Forms.ColumnHeader();
            this.HardwareID = new System.Windows.Forms.ColumnHeader();
            this.Departamento = new System.Windows.Forms.ColumnHeader();
            this.Status = new System.Windows.Forms.ColumnHeader();
            this.label2 = new System.Windows.Forms.Label();
            this.Icone_voltar = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Botao_Atualizar = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Icone_voltar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Botao_Atualizar)).BeginInit();
            this.SuspendLayout();
            // 
            // Botao_relatorio
            // 
            this.Botao_relatorio.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Botao_relatorio.BackColor = System.Drawing.Color.Orange;
            this.Botao_relatorio.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Botao_relatorio.Font = new System.Drawing.Font("Franklin Gothic Heavy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Botao_relatorio.ForeColor = System.Drawing.Color.White;
            this.Botao_relatorio.Location = new System.Drawing.Point(885, 950);
            this.Botao_relatorio.Name = "Botao_relatorio";
            this.Botao_relatorio.Size = new System.Drawing.Size(150, 35);
            this.Botao_relatorio.TabIndex = 7;
            this.Botao_relatorio.Text = "Relatório";
            this.Botao_relatorio.UseVisualStyleBackColor = false;
            this.Botao_relatorio.Click += new System.EventHandler(this.Botao_relatorio_Click_1);
            // 
            // List_ativos
            // 
            this.List_ativos.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.List_ativos.Alignment = System.Windows.Forms.ListViewAlignment.Default;
            this.List_ativos.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.List_ativos.BackColor = System.Drawing.Color.Gainsboro;
            this.List_ativos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.List_ativos.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ID,
            this.HardwareID,
            this.Departamento,
            this.Status});
            this.List_ativos.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.List_ativos.ForeColor = System.Drawing.Color.Black;
            this.List_ativos.GridLines = true;
            this.List_ativos.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.List_ativos.HideSelection = false;
            this.List_ativos.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.List_ativos.Location = new System.Drawing.Point(360, 246);
            this.List_ativos.Name = "List_ativos";
            this.List_ativos.Size = new System.Drawing.Size(1200, 676);
            this.List_ativos.TabIndex = 6;
            this.List_ativos.UseCompatibleStateImageBehavior = false;
            this.List_ativos.View = System.Windows.Forms.View.Details;
            // 
            // ID
            // 
            this.ID.Text = "ID";
            this.ID.Width = 150;
            // 
            // HardwareID
            // 
            this.HardwareID.Text = "Hardware ID";
            this.HardwareID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.HardwareID.Width = 400;
            // 
            // Departamento
            // 
            this.Departamento.Text = "Departamento";
            this.Departamento.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Departamento.Width = 350;
            // 
            // Status
            // 
            this.Status.Text = "Status";
            this.Status.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Status.Width = 300;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label2.Location = new System.Drawing.Point(1619, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(273, 32);
            this.label2.TabIndex = 8;
            this.label2.Text = "Bem vindo, usuário";
            // 
            // Icone_voltar
            // 
            this.Icone_voltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Icone_voltar.Image = ((System.Drawing.Image)(resources.GetObject("Icone_voltar.Image")));
            this.Icone_voltar.Location = new System.Drawing.Point(10, 10);
            this.Icone_voltar.Name = "Icone_voltar";
            this.Icone_voltar.Size = new System.Drawing.Size(32, 32);
            this.Icone_voltar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Icone_voltar.TabIndex = 40;
            this.Icone_voltar.TabStop = false;
            this.Icone_voltar.Click += new System.EventHandler(this.Icone_voltar_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(907, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(109, 88);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 41;
            this.pictureBox1.TabStop = false;
            // 
            // Botao_Atualizar
            // 
            this.Botao_Atualizar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Botao_Atualizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Botao_Atualizar.Image = ((System.Drawing.Image)(resources.GetObject("Botao_Atualizar.Image")));
            this.Botao_Atualizar.Location = new System.Drawing.Point(1578, 890);
            this.Botao_Atualizar.Name = "Botao_Atualizar";
            this.Botao_Atualizar.Size = new System.Drawing.Size(32, 32);
            this.Botao_Atualizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Botao_Atualizar.TabIndex = 42;
            this.Botao_Atualizar.TabStop = false;
            this.Botao_Atualizar.Click += new System.EventHandler(this.Botao_Atualizar_Click_1);
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.Orange;
            this.label6.Location = new System.Drawing.Point(824, 162);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(271, 37);
            this.label6.TabIndex = 88;
            this.label6.Text = "Visualizar ativos";
            // 
            // TelaInicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1904, 1041);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Botao_Atualizar);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Icone_voltar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Botao_relatorio);
            this.Controls.Add(this.List_ativos);
            this.MaximizeBox = false;
            this.Name = "TelaInicial";
            this.Text = "TelaInicial";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.TelaInicial_FormClosed);
            this.Load += new System.EventHandler(this.TelaInicial_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Icone_voltar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Botao_Atualizar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Botao_relatorio;
        private System.Windows.Forms.ListView List_ativos;
        private System.Windows.Forms.ColumnHeader ID;
        private System.Windows.Forms.ColumnHeader HardwareID;
        private System.Windows.Forms.ColumnHeader Departamento;
        private System.Windows.Forms.ColumnHeader Status;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox Icone_voltar;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox Botao_Atualizar;
        private System.Windows.Forms.Label label6;
    }
}