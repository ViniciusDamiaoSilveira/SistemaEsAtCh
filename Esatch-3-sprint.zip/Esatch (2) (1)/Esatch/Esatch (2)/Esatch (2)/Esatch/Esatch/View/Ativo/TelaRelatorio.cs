﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Ativo
{
    public partial class TelaRelatorio : Form
    {
        string cpf;
        public TelaRelatorio(string cpf)
        {
            this.cpf = cpf;
            InitializeComponent();
        }

        Controller.RelatorioController controlador = new Controller.RelatorioController();

        private void TelaRelatorio_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void botao_relatorio_Click(object sender, EventArgs e)
        {
            if(Txt_depart.Text == "" || Txt_descri.Text == "" || Txt_nome.Text == "") {
                MessageBox.Show("Por favor, preencha todos os campos.", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else {
                controlador.EnviarRelatorioAtivos(Txt_nome.Text, Txt_depart.Text, Txt_descri.Text, cpf);
                MessageBox.Show("Relatório sobre os ativos enviado com sucesso.", "Enviado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TelaInicial telainicial = new TelaInicial(cpf);
                telainicial.Show();
                this.Hide();
            }

        }

        private void Icone_voltar_Click_1(object sender, EventArgs e) {
            TelaInicial telainicial = new TelaInicial(cpf);
            telainicial.Show();
            this.Hide();
        }
    }
}
