﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Esatch.Controller
{
    class RelatorioController
    {
        internal void EnviarRelatorioEstoque(string nome, string departamento, string descricao, string cpf) {
            Model.Relatorio.EnviarRelatorioEstoque(nome, departamento, descricao, cpf);
        }

        internal void EnviarRelatorioAtivos(string nome, string departamento, string descricao, string cpf) {
            Model.Relatorio.EnviarRelatorioAtivos(nome, departamento, descricao, cpf);
        }
    }
}
