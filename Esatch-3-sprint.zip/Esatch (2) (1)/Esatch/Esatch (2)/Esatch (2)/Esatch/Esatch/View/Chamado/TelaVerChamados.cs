﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Chamado
{
    public partial class TelaVerChamados : Form
    {
        string cpf;
        public TelaVerChamados(string cpf)
        {
            this.cpf = cpf;
            InitializeComponent();
        }

        Controller.ChamadoController controlador = new Controller.ChamadoController();

        private void TelaVerChamados_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void TelaVerChamados_Load(object sender, EventArgs e)
        {
            List<Model.Chamado> lista = controlador.MostrarChamados(cpf);

            foreach (Model.Chamado chamado in lista)
            {
                ListViewItem linha = new ListViewItem();
                linha.Text = chamado.Codigo;
                linha.SubItems.Add(chamado.Titulo);
                linha.SubItems.Add(chamado.Status);
                linha.SubItems.Add(chamado.Prioridade);
                list_chamados.Items.Add(linha);
            }
        }

        private void Icone_voltar_Click(object sender, EventArgs e) {
            TelaInicio telainicio = new TelaInicio(cpf);
            telainicio.Show();
            this.Hide();
        }

        private void Botao_classificar_Click(object sender, EventArgs e) {
            TelaEscolhaChamado telaescolha = new TelaEscolhaChamado(cpf);
            telaescolha.Show();
            this.Hide();
        }

        private void icone_atualizar_Click(object sender, EventArgs e)
        {
            list_chamados.Items.Clear();

            List<Model.Chamado> lista = controlador.MostrarChamados(cpf);

            foreach (Model.Chamado chamado in lista)
            {
                ListViewItem linha = new ListViewItem();
                linha.Text = chamado.Codigo;
                linha.SubItems.Add(chamado.Titulo);
                linha.SubItems.Add(chamado.Status);
                linha.SubItems.Add(chamado.Prioridade);
                list_chamados.Items.Add(linha);
            }
        }
    }
}
