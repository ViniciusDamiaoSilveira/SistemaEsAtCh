﻿
namespace Esatch.View.Chamado
{
    partial class TelaEnviarChamado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label6 = new System.Windows.Forms.Label();
            this.Box_prioridade = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Botao_solicitar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Txt_descricao = new System.Windows.Forms.TextBox();
            this.Txt_departamento = new System.Windows.Forms.TextBox();
            this.Txt_titulo = new System.Windows.Forms.TextBox();
            this.Icone_voltar = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Icone_voltar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label6.Location = new System.Drawing.Point(654, 270);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 29);
            this.label6.TabIndex = 25;
            this.label6.Text = "Prioridade";
            // 
            // Box_prioridade
            // 
            this.Box_prioridade.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Box_prioridade.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Box_prioridade.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Box_prioridade.FormattingEnabled = true;
            this.Box_prioridade.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.Box_prioridade.Location = new System.Drawing.Point(660, 300);
            this.Box_prioridade.Name = "Box_prioridade";
            this.Box_prioridade.Size = new System.Drawing.Size(100, 29);
            this.Box_prioridade.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label5.Location = new System.Drawing.Point(215, 190);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 29);
            this.label5.TabIndex = 23;
            this.label5.Text = "Título";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label4.Location = new System.Drawing.Point(215, 350);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 29);
            this.label4.TabIndex = 22;
            this.label4.Text = "Descrição";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label3.Location = new System.Drawing.Point(215, 270);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(147, 29);
            this.label3.TabIndex = 21;
            this.label3.Text = "Departamento";
            // 
            // Botao_solicitar
            // 
            this.Botao_solicitar.BackColor = System.Drawing.Color.Orange;
            this.Botao_solicitar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Botao_solicitar.Font = new System.Drawing.Font("Franklin Gothic Heavy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Botao_solicitar.ForeColor = System.Drawing.Color.White;
            this.Botao_solicitar.Location = new System.Drawing.Point(610, 800);
            this.Botao_solicitar.Name = "Botao_solicitar";
            this.Botao_solicitar.Size = new System.Drawing.Size(150, 35);
            this.Botao_solicitar.TabIndex = 5;
            this.Botao_solicitar.Text = "Solicitar";
            this.Botao_solicitar.UseVisualStyleBackColor = false;
            this.Botao_solicitar.Click += new System.EventHandler(this.Botao_solicitar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.Orange;
            this.label2.Location = new System.Drawing.Point(394, 135);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(226, 33);
            this.label2.TabIndex = 19;
            this.label2.Text = "Solicitar Chamado";
            // 
            // Txt_descricao
            // 
            this.Txt_descricao.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Txt_descricao.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Txt_descricao.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Txt_descricao.Location = new System.Drawing.Point(221, 380);
            this.Txt_descricao.MaxLength = 500;
            this.Txt_descricao.Multiline = true;
            this.Txt_descricao.Name = "Txt_descricao";
            this.Txt_descricao.Size = new System.Drawing.Size(539, 380);
            this.Txt_descricao.TabIndex = 4;
            // 
            // Txt_departamento
            // 
            this.Txt_departamento.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Txt_departamento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Txt_departamento.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Txt_departamento.Location = new System.Drawing.Point(221, 300);
            this.Txt_departamento.MaxLength = 30;
            this.Txt_departamento.Name = "Txt_departamento";
            this.Txt_departamento.Size = new System.Drawing.Size(399, 29);
            this.Txt_departamento.TabIndex = 2;
            // 
            // Txt_titulo
            // 
            this.Txt_titulo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Txt_titulo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Txt_titulo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Txt_titulo.Location = new System.Drawing.Point(221, 220);
            this.Txt_titulo.MaxLength = 30;
            this.Txt_titulo.Name = "Txt_titulo";
            this.Txt_titulo.Size = new System.Drawing.Size(539, 29);
            this.Txt_titulo.TabIndex = 1;
            // 
            // Icone_voltar
            // 
            this.Icone_voltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Icone_voltar.Image = global::Esatch.Properties.Resources.icone_voltar_definitivo;
            this.Icone_voltar.Location = new System.Drawing.Point(10, 10);
            this.Icone_voltar.Name = "Icone_voltar";
            this.Icone_voltar.Size = new System.Drawing.Size(32, 32);
            this.Icone_voltar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Icone_voltar.TabIndex = 40;
            this.Icone_voltar.TabStop = false;
            this.Icone_voltar.Click += new System.EventHandler(this.Icone_voltar_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = global::Esatch.Properties.Resources.LogoCh;
            this.pictureBox1.Location = new System.Drawing.Point(449, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(101, 77);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 41;
            this.pictureBox1.TabStop = false;
            // 
            // TelaEnviarChamado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(984, 861);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Icone_voltar);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Box_prioridade);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Botao_solicitar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Txt_descricao);
            this.Controls.Add(this.Txt_departamento);
            this.Controls.Add(this.Txt_titulo);
            this.MaximizeBox = false;
            this.Name = "TelaEnviarChamado";
            this.Text = "TelaEnviarChamado";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.TelaEnviarChamado_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.Icone_voltar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox Box_prioridade;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Botao_solicitar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Txt_descricao;
        private System.Windows.Forms.TextBox Txt_departamento;
        private System.Windows.Forms.TextBox Txt_titulo;
        private System.Windows.Forms.PictureBox Icone_voltar;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}