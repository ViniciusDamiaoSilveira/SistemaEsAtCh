﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Admiministrador
{
    public partial class TelaRelatorioEstoque : Form
    {
        public TelaRelatorioEstoque()
        {
            InitializeComponent();
        }

        private void TelaRelatorioEstoque_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        Controller.AdministradorController controlador = new Controller.AdministradorController();
        private void TelaRelatorioEstoque_Load(object sender, EventArgs e)
        {
            List<Model.Administrador> lista = controlador.MostrarRelatorioEstoque();

            foreach (Model.Administrador administrador in lista)
            {
                ListViewItem linha = new ListViewItem();
                linha.Text = administrador.Codigo;
                linha.SubItems.Add(administrador.Nome);
                linha.SubItems.Add(administrador.Cpf);
                linha.SubItems.Add(administrador.Departamento);
                list_relatorio.Items.Add(linha);
            }
        }
    }
}
