﻿
namespace Esatch.View.Admiministrador
{
    partial class TelaEscolhaAtivo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaEscolhaAtivo));
            this.label6 = new System.Windows.Forms.Label();
            this.icone_voltar = new System.Windows.Forms.PictureBox();
            this.botao_mostrar = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.Txt_id = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.icone_voltar)).BeginInit();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.Orange;
            this.label6.Location = new System.Drawing.Point(199, 81);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(302, 37);
            this.label6.TabIndex = 76;
            this.label6.Text = "Insira o ID do ativo";
            // 
            // icone_voltar
            // 
            this.icone_voltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.icone_voltar.Image = ((System.Drawing.Image)(resources.GetObject("icone_voltar.Image")));
            this.icone_voltar.Location = new System.Drawing.Point(10, 10);
            this.icone_voltar.Name = "icone_voltar";
            this.icone_voltar.Size = new System.Drawing.Size(32, 32);
            this.icone_voltar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.icone_voltar.TabIndex = 75;
            this.icone_voltar.TabStop = false;
            this.icone_voltar.Click += new System.EventHandler(this.icone_voltar_Click);
            // 
            // botao_mostrar
            // 
            this.botao_mostrar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.botao_mostrar.BackColor = System.Drawing.Color.Orange;
            this.botao_mostrar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.botao_mostrar.Font = new System.Drawing.Font("Franklin Gothic Heavy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.botao_mostrar.ForeColor = System.Drawing.Color.White;
            this.botao_mostrar.Location = new System.Drawing.Point(480, 254);
            this.botao_mostrar.Name = "botao_mostrar";
            this.botao_mostrar.Size = new System.Drawing.Size(131, 35);
            this.botao_mostrar.TabIndex = 74;
            this.botao_mostrar.Text = "Mostrar";
            this.botao_mostrar.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label5.Location = new System.Drawing.Point(68, 155);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 29);
            this.label5.TabIndex = 73;
            this.label5.Text = "ID";
            // 
            // Txt_id
            // 
            this.Txt_id.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Txt_id.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Txt_id.Location = new System.Drawing.Point(72, 187);
            this.Txt_id.Name = "Txt_id";
            this.Txt_id.Size = new System.Drawing.Size(539, 29);
            this.Txt_id.TabIndex = 72;
            // 
            // TelaEscolhaAtivo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(684, 361);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.icone_voltar);
            this.Controls.Add(this.botao_mostrar);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Txt_id);
            this.MaximizeBox = false;
            this.Name = "TelaEscolhaAtivo";
            this.Text = "TelaVerificarAtivo";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.TelaEscolhaAtivo_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.icone_voltar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox icone_voltar;
        private System.Windows.Forms.Button botao_mostrar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Txt_id;
    }
}