﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Esatch
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        Controller.UsuarioController controlador = new Controller.UsuarioController();

        private void botao_entrar_Click(object sender, EventArgs e) {
            string status = controlador.EntrarUsuario(txt_cpf.Text, txt_senha.Text);
            if (status == "EXISTE") {
                TelaSistemas telainicial = new TelaSistemas(txt_cpf.Text);
                telainicial.Show();
                this.Hide();
            } else {
                MessageBox.Show("CPF ou Senha errados.", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e) {
            Application.Exit();
        }

        private void botao_admin_Click(object sender, EventArgs e) {
            View.Admiministrador.TelaLogin telalogin = new View.Admiministrador.TelaLogin();
            telalogin.Show();
            this.Hide();
        }
    }
}
