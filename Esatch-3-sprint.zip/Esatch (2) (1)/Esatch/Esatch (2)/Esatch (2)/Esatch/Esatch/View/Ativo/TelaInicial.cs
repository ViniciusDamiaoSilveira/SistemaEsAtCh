﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Net.NetworkInformation;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Ativo
{
    public partial class TelaInicial : Form
    {
        string cpf;
        public TelaInicial(string cpf) {
            this.cpf = cpf;
            InitializeComponent();
        }

        Controller.AtivoController controladorAtivo = new Controller.AtivoController();

        private void TelaInicial_Load(object sender, EventArgs e) {

            List<Model.Ativo> lista = controladorAtivo.ListarAtivos();

            foreach (Model.Ativo ativo in lista) {
                ListViewItem linha = new ListViewItem();
                linha.Text = ativo.Id;
                linha.SubItems.Add(ativo.HardwareID);
                linha.SubItems.Add(ativo.Departamento);
                linha.SubItems.Add(ativo.Status);
                List_ativos.Items.Add(linha);
            }
        }

        private void TelaInicial_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        

       

        private void Botao_Atualizar_Click_1(object sender, EventArgs e) {
            List_ativos.Items.Clear();
            List<Model.Ativo> lista = controladorAtivo.ListarAtivos();

            foreach (Model.Ativo ativo in lista) {
                ListViewItem linha = new ListViewItem();
                linha.Text = ativo.Id;
                linha.SubItems.Add(ativo.HardwareID);
                linha.SubItems.Add(ativo.Departamento);
                linha.SubItems.Add(ativo.Status);
                List_ativos.Items.Add(linha);
            }
        }

        private void Icone_voltar_Click_1(object sender, EventArgs e) {
           TelaSistemas telainicial = new TelaSistemas(cpf);
            telainicial.Show();
            this.Hide();
        }

        private void Botao_relatorio_Click_1(object sender, EventArgs e) {
            TelaRelatorio telarelatorio = new TelaRelatorio(cpf);
            telarelatorio.Show();
            this.Hide();
        }
    }
}
