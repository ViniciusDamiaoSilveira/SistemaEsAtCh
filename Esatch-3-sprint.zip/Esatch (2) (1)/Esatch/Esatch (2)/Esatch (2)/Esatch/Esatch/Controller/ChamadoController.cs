﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Esatch.Controller
{
    class ChamadoController
    {
        internal void SolicitarChamado(string titulo, string prioridade,
       string departamento, string descricao, string cpf) {
            Model.Chamado.EnviarChamados(titulo, prioridade, departamento, descricao, cpf);
        }

        internal List<Model.Chamado> MostrarChamados(string cpf)
        {
            return Model.Chamado.ListarChamados(cpf);
        }

        internal string VerificarChamado(string codigo, string cpf)
        {
            return Model.Chamado.VerificarChamado(codigo, cpf);
        }

        internal void EnviarClassificacao(string codigo, string avaliacao, string nota)
        {
            Model.Chamado.EnviarClassificacao(codigo, avaliacao, nota);
        }

        internal List<Model.Chamado> ListarChamadosAberto()
        {
            return Model.Chamado.ListarChamadosAberto();
        }
        internal List<Model.Chamado> ListarChamadosFechado()
        {
            return Model.Chamado.ListarChamadosFechados();
        }
    }
}
