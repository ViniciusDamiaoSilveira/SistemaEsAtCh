﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Text;

namespace Esatch.Model
{
    class Relatorio
    {
        static string dados_conexao = "Server=10.87.100.6;Database=esatch;User id = aluno; Password=Senai1234";
        private string titulo, departamento, descricao, cpf;

        public Relatorio(string titulo, string departamento, string descricao, string cpf) {
            this.titulo = titulo;
            this.departamento = departamento;
            this.descricao = descricao;
            this.cpf = cpf;
        }

        public string Titulo  { get => titulo; set => titulo = value; }
        public string Departamento { get => departamento; set => departamento = value; }
        public string Descricao { get => descricao; set => descricao = value; }
        public string Cpf { get => cpf; set => cpf = value; }

        public static string EnviarRelatorioEstoque(string nome, string departamento, string descricao, string cpf) {
            //Objeto da conexão
            MySqlConnection con = new MySqlConnection(dados_conexao);

            try {
                //Abrir conexão
                con.Open();

                //Objeto do comando sql
                MySqlCommand comando = new MySqlCommand("INSERT INTO relatorio_estoque(nome, departamento," +
                    "descricao, cpfe) VALUES" +
                    " (@nome, @departamento, @descricao, @cpf)", con);


                //Adicionando valores para as variáveis
                comando.Parameters.AddWithValue("@nome", nome);
                comando.Parameters.AddWithValue("@departamento", departamento);
                comando.Parameters.AddWithValue("@descricao", descricao);
                comando.Parameters.AddWithValue("@cpf", cpf);


                comando.ExecuteNonQuery();

                //Fechar conexão
                con.Close();

                return "DEU CERTO";

            } catch (Exception ex) {
                return ex.ToString();
            }

        }

        public static string EnviarRelatorioAtivos(string nome, string departamento, string descricao, string cpf) {
            //Objeto da conexão
            MySqlConnection con = new MySqlConnection(dados_conexao);

            try {
                //Abrir conexão
                con.Open();

                //Objeto do comando sql
                MySqlCommand comando = new MySqlCommand("INSERT INTO relatorio_ativo(nome, departamento," +
                    "descricao, cpfa) VALUES" +
                    "(@nome, @departamento, @descricao, @cpf)", con);


                //Adicionando valores para as variáveis
                comando.Parameters.AddWithValue("@nome", nome);
                comando.Parameters.AddWithValue("@departamento", departamento);
                comando.Parameters.AddWithValue("@descricao", descricao);
                comando.Parameters.AddWithValue("@cpf", cpf);


                comando.ExecuteNonQuery();

                //Fechar conexão
                con.Close();

                return "DEU CERTO";

            } catch (Exception ex) {
                return ex.ToString();
            }
        }

        //Função Mostrar relatório do estoque
        public static List<Administrador> MostrarRelatorioEstoque()
        {
            //Objeto da lista de estoque
            List<Administrador> lista = new List<Administrador>();

            //Objeto da conexão
            MySqlConnection con = new MySqlConnection(dados_conexao);

            try
            {
                //Abrir conexão
                con.Open();
                MySqlCommand comando = new MySqlCommand("SELECT * FROM relatorio_estoque", con);

                //Objeto do leitor
                MySqlDataReader leitor = comando.ExecuteReader();

                //Leitura dos dados 
                while (leitor.Read())
                {
                    Administrador adm = new Administrador(
                    leitor["codigo_relatorio"].ToString(),
                    leitor["nome"].ToString(),
                    leitor["cpfe"].ToString(),
                    leitor["departamento"].ToString());

                    lista.Add(adm);
                }

                //Fechar conexão
                con.Close();
                return lista;

            }
            catch (Exception ex)
            {
                return null;
            }


        }
    }
}
