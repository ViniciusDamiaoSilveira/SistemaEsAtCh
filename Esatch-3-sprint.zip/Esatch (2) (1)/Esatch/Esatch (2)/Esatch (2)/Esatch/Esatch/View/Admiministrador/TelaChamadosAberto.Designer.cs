﻿
namespace Esatch.View.Admiministrador
{
    partial class TelaChamadosAberto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaChamadosAberto));
            this.list_chamados = new System.Windows.Forms.ListView();
            this.ID = new System.Windows.Forms.ColumnHeader();
            this.Titulo = new System.Windows.Forms.ColumnHeader();
            this.Status = new System.Windows.Forms.ColumnHeader();
            this.Prioridade = new System.Windows.Forms.ColumnHeader();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Botao_classificar = new System.Windows.Forms.Button();
            this.Icone_voltar = new System.Windows.Forms.PictureBox();
            this.icone_atualizar = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Icone_voltar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.icone_atualizar)).BeginInit();
            this.SuspendLayout();
            // 
            // list_chamados
            // 
            this.list_chamados.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.list_chamados.Alignment = System.Windows.Forms.ListViewAlignment.Default;
            this.list_chamados.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.list_chamados.BackColor = System.Drawing.Color.Gainsboro;
            this.list_chamados.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ID,
            this.Titulo,
            this.Status,
            this.Prioridade});
            this.list_chamados.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.list_chamados.ForeColor = System.Drawing.Color.Black;
            this.list_chamados.GridLines = true;
            this.list_chamados.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.list_chamados.HideSelection = false;
            this.list_chamados.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.list_chamados.Location = new System.Drawing.Point(66, 202);
            this.list_chamados.Name = "list_chamados";
            this.list_chamados.Size = new System.Drawing.Size(854, 580);
            this.list_chamados.TabIndex = 8;
            this.list_chamados.UseCompatibleStateImageBehavior = false;
            this.list_chamados.View = System.Windows.Forms.View.Details;
            // 
            // ID
            // 
            this.ID.Text = "ID";
            this.ID.Width = 150;
            // 
            // Titulo
            // 
            this.Titulo.Text = "Titulo";
            this.Titulo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Titulo.Width = 400;
            // 
            // Status
            // 
            this.Status.Text = "Status";
            this.Status.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Status.Width = 200;
            // 
            // Prioridade
            // 
            this.Prioridade.Text = "Prioridade";
            this.Prioridade.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Prioridade.Width = 100;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(449, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(101, 77);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 74;
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.Orange;
            this.label6.Location = new System.Drawing.Point(251, 125);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(497, 37);
            this.label6.TabIndex = 73;
            this.label6.Text = "Visualizar chamados em aberto";
            // 
            // Botao_classificar
            // 
            this.Botao_classificar.BackColor = System.Drawing.Color.Orange;
            this.Botao_classificar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Botao_classificar.Font = new System.Drawing.Font("Franklin Gothic Heavy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Botao_classificar.ForeColor = System.Drawing.Color.White;
            this.Botao_classificar.Location = new System.Drawing.Point(381, 806);
            this.Botao_classificar.Name = "Botao_classificar";
            this.Botao_classificar.Size = new System.Drawing.Size(242, 35);
            this.Botao_classificar.TabIndex = 75;
            this.Botao_classificar.Text = "Visualizar Chamado";
            this.Botao_classificar.UseVisualStyleBackColor = false;
            // 
            // Icone_voltar
            // 
            this.Icone_voltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Icone_voltar.Image = ((System.Drawing.Image)(resources.GetObject("Icone_voltar.Image")));
            this.Icone_voltar.Location = new System.Drawing.Point(10, 10);
            this.Icone_voltar.Name = "Icone_voltar";
            this.Icone_voltar.Size = new System.Drawing.Size(32, 32);
            this.Icone_voltar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Icone_voltar.TabIndex = 76;
            this.Icone_voltar.TabStop = false;
            this.Icone_voltar.Click += new System.EventHandler(this.Icone_voltar_Click);
            // 
            // icone_atualizar
            // 
            this.icone_atualizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.icone_atualizar.Image = ((System.Drawing.Image)(resources.GetObject("icone_atualizar.Image")));
            this.icone_atualizar.Location = new System.Drawing.Point(926, 750);
            this.icone_atualizar.Name = "icone_atualizar";
            this.icone_atualizar.Size = new System.Drawing.Size(32, 32);
            this.icone_atualizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.icone_atualizar.TabIndex = 77;
            this.icone_atualizar.TabStop = false;
            this.icone_atualizar.Click += new System.EventHandler(this.icone_atualizar_Click);
            // 
            // TelaChamadosAberto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(984, 861);
            this.Controls.Add(this.icone_atualizar);
            this.Controls.Add(this.Icone_voltar);
            this.Controls.Add(this.Botao_classificar);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.list_chamados);
            this.MaximizeBox = false;
            this.Name = "TelaChamadosAberto";
            this.Text = "TelaChamadosInicial";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.TelaChamadosAberto_FormClosed);
            this.Load += new System.EventHandler(this.TelaChamadosInicial_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Icone_voltar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.icone_atualizar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView list_chamados;
        private System.Windows.Forms.ColumnHeader ID;
        private System.Windows.Forms.ColumnHeader Titulo;
        private System.Windows.Forms.ColumnHeader Status;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Botao_classificar;
        private System.Windows.Forms.PictureBox Icone_voltar;
        private System.Windows.Forms.PictureBox icone_atualizar;
        private System.Windows.Forms.ColumnHeader Prioridade;
    }
}