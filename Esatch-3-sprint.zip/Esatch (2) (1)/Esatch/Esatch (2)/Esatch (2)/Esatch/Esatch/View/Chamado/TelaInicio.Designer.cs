﻿namespace Esatch.View.Chamado
{
    partial class TelaInicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Botao_solicitar = new System.Windows.Forms.Button();
            this.Botao_visualizar_chamado = new System.Windows.Forms.Button();
            this.Icone_voltar = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Icone_voltar)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Esatch.Properties.Resources.LogoCh;
            this.pictureBox4.Location = new System.Drawing.Point(449, 20);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(101, 77);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox4.TabIndex = 30;
            this.pictureBox4.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(133)))), ((int)(((byte)(36)))));
            this.label1.Location = new System.Drawing.Point(266, 188);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(468, 56);
            this.label1.TabIndex = 31;
            this.label1.Text = "Bem vindo, usuário";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label3.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label3.Location = new System.Drawing.Point(356, 369);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(289, 29);
            this.label3.TabIndex = 33;
            this.label3.Text = "qual área você deseja ir.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label2.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label2.Location = new System.Drawing.Point(370, 339);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(260, 29);
            this.label2.TabIndex = 32;
            this.label2.Text = "Por favor, selecione a";
            // 
            // Botao_solicitar
            // 
            this.Botao_solicitar.BackColor = System.Drawing.Color.Orange;
            this.Botao_solicitar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Botao_solicitar.Font = new System.Drawing.Font("Franklin Gothic Heavy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Botao_solicitar.ForeColor = System.Drawing.Color.White;
            this.Botao_solicitar.Location = new System.Drawing.Point(380, 551);
            this.Botao_solicitar.Name = "Botao_solicitar";
            this.Botao_solicitar.Size = new System.Drawing.Size(222, 35);
            this.Botao_solicitar.TabIndex = 1;
            this.Botao_solicitar.Text = "Solicitar Chamado";
            this.Botao_solicitar.UseVisualStyleBackColor = false;
            this.Botao_solicitar.Click += new System.EventHandler(this.TelaChamado);
            // 
            // Botao_visualizar_chamado
            // 
            this.Botao_visualizar_chamado.BackColor = System.Drawing.Color.Orange;
            this.Botao_visualizar_chamado.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Botao_visualizar_chamado.Font = new System.Drawing.Font("Franklin Gothic Heavy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Botao_visualizar_chamado.ForeColor = System.Drawing.Color.White;
            this.Botao_visualizar_chamado.Location = new System.Drawing.Point(380, 614);
            this.Botao_visualizar_chamado.Name = "Botao_visualizar_chamado";
            this.Botao_visualizar_chamado.Size = new System.Drawing.Size(222, 35);
            this.Botao_visualizar_chamado.TabIndex = 2;
            this.Botao_visualizar_chamado.Text = "Visualizar Chamado";
            this.Botao_visualizar_chamado.UseVisualStyleBackColor = false;
            this.Botao_visualizar_chamado.Click += new System.EventHandler(this.Botao_visualizar_chamado_Click);
            // 
            // Icone_voltar
            // 
            this.Icone_voltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Icone_voltar.Image = global::Esatch.Properties.Resources.icone_voltar_definitivo;
            this.Icone_voltar.Location = new System.Drawing.Point(10, 10);
            this.Icone_voltar.Name = "Icone_voltar";
            this.Icone_voltar.Size = new System.Drawing.Size(32, 32);
            this.Icone_voltar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Icone_voltar.TabIndex = 40;
            this.Icone_voltar.TabStop = false;
            this.Icone_voltar.Click += new System.EventHandler(this.Icone_voltar_Click);
            // 
            // TelaInicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(984, 861);
            this.Controls.Add(this.Icone_voltar);
            this.Controls.Add(this.Botao_visualizar_chamado);
            this.Controls.Add(this.Botao_solicitar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox4);
            this.MaximizeBox = false;
            this.Name = "TelaInicio";
            this.Text = "TelaInicio";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.TelaInicio_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Icone_voltar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Botao_solicitar;
        private System.Windows.Forms.Button Botao_visualizar_chamado;
        private System.Windows.Forms.PictureBox Icone_voltar;
    }
}