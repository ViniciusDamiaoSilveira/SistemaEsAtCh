﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace Esatch.Controller
{
    class AdministradorController
    {
        internal string EntrarADM(string codigo) {

            string adm = Model.Administrador.EntrarADM(codigo);
            return adm;
        }

        internal List<Model.Administrador> MostrarRelatorioEstoque()
        {
            return Model.Administrador.MostrarRelatorioEstoque();
        }

        public string Criptografar(string dados) {
            SHA256 sha256 = SHA256.Create();
            byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(dados));
            StringBuilder builder = new StringBuilder();

            for (int i = 0; i < bytes.Length; i++) {
                builder.Append(bytes[i].ToString("x2"));
            }
            return builder.ToString();
        }

        public void CadastrarUsuario(string cpf, string senha) {
            Model.Administrador.CadastrarUsuario(cpf, Criptografar(senha));
        }

    }
}
