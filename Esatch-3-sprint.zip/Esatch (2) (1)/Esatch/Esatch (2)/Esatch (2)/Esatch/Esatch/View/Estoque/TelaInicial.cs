﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Estoque
{
    public partial class TelaInicial : Form
    {
        string cpf;
        public TelaInicial(string cpf)
        {
            this.cpf = cpf;
            InitializeComponent();
        }

        Controller.EstoqueController controlador = new Controller.EstoqueController();
        private void mostrarEstoque(object sender, EventArgs e)
        {
            List<Model.Estoque> lista = controlador.ListarEstoque();
            foreach (Model.Estoque estoque in lista)
            {
                ListViewItem linha = new ListViewItem();
                linha.Text = estoque.Id;
                linha.SubItems.Add(estoque.Codigo);
                linha.SubItems.Add(estoque.Nome);
                linha.SubItems.Add(estoque.Quantidade);
                linha.SubItems.Add(estoque.Local);
                linha.SubItems.Add(estoque.Vendedor);
                linha.SubItems.Add(estoque.Status);

                list_estoque.Items.Add(linha);
            }


        }


        private void fecharPrograma(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }    

        private void icone_voltar_Click(object sender, EventArgs e)
        {
            TelaSistemas telainicial = new TelaSistemas(cpf);
            telainicial.Show();
            this.Hide();
        }

        private void botao_adicionar_Click(object sender, EventArgs e)
        {
            Estoque.TelaAdicionarProduto telaAdicionar = new TelaAdicionarProduto(cpf);
            telaAdicionar.Show();
            this.Hide();
        }

        private void botao_editar_Click(object sender, EventArgs e)
        {
            Estoque.TelaEscolhaProduto telaEsolha = new TelaEscolhaProduto();
            telaEsolha.Show();
            this.Hide();
        }

        private void botao_relatori_Click(object sender, EventArgs e)
        {
            TelaRelatorio telarelatorio = new TelaRelatorio(cpf);
            telarelatorio.Show();
            this.Hide();
        }

        private void icone_atualizar_Click(object sender, EventArgs e)
        {
            list_estoque.Items.Clear();
            List<Model.Estoque> lista = controlador.ListarEstoque();
            foreach (Model.Estoque estoque in lista)
            {
                ListViewItem linha = new ListViewItem();
                linha.Text = estoque.Id;
                linha.SubItems.Add(estoque.Codigo);
                linha.SubItems.Add(estoque.Nome);
                linha.SubItems.Add(estoque.Quantidade);
                linha.SubItems.Add(estoque.Local);
                linha.SubItems.Add(estoque.Vendedor);
                linha.SubItems.Add(estoque.Status);

                list_estoque.Items.Add(linha);
            }
        }
    }
}
