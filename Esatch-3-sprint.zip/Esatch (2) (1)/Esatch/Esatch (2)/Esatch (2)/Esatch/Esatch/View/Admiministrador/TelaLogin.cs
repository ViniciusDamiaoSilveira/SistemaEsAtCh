﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Admiministrador
{
    public partial class TelaLogin : Form
    {
        public TelaLogin()
        {
            InitializeComponent();
        }

        Controller.AdministradorController controlador = new Controller.AdministradorController();
        
        private void botao_entrar_Click(object sender, EventArgs e) {
         string adm = controlador.EntrarADM(txt_codigo.Text);
            if(adm == "EXISTE") {
                TelaInicial telainicial = new TelaInicial();
                telainicial.Show();
                this.Hide();
            } else {
                MessageBox.Show("Código errado, tente novamente.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TelaLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void icone_voltar_Click(object sender, EventArgs e)
        {
            Form1 telainicial = new Form1();
            telainicial.Show();
            this.Hide();
        }
    }
}
