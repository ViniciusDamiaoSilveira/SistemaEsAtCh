﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Admiministrador
{
    public partial class TelaAtivosInicial : Form
    {
        public TelaAtivosInicial()
        {
            InitializeComponent();
        }

        Controller.AtivoController controlador = new Controller.AtivoController();

        private void TelaAtivosInicial_Load(object sender, EventArgs e)
        {
            List<Model.Ativo> lista = controlador.ListarAtivos();

            foreach (Model.Ativo ativo in lista)
            {
                ListViewItem linha = new ListViewItem();
                linha.Text = ativo.Id;
                linha.SubItems.Add(ativo.HardwareID);
                linha.SubItems.Add(ativo.Departamento);
                linha.SubItems.Add(ativo.Status);
                List_ativos.Items.Add(linha);
            }
        }

        private void TelaAtivosInicial_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void icone_voltar_Click(object sender, EventArgs e)
        {
            TelaInicial telaInicial = new TelaInicial();
            telaInicial.Show();
            this.Hide();

        }

        private void Icone_atualizar_Click(object sender, EventArgs e)
        {
            List_ativos.Items.Clear();
            List<Model.Ativo> lista = controlador.ListarAtivos();

            foreach (Model.Ativo ativo in lista)
            {
                ListViewItem linha = new ListViewItem();
                linha.Text = ativo.Id;
                linha.SubItems.Add(ativo.HardwareID);
                linha.SubItems.Add(ativo.Departamento);
                linha.SubItems.Add(ativo.Status);
                List_ativos.Items.Add(linha);
            }
        }

        private void botao_adicionar_Click(object sender, EventArgs e)
        {
            TelaAdicionarAtivos tela_adicionar = new TelaAdicionarAtivos();
            tela_adicionar.Show();
            this.Hide();
        }

        private void botao_editar_Click(object sender, EventArgs e)
        {
            TelaEscolhaAtivo telaescolha = new TelaEscolhaAtivo();
            telaescolha.Show();
            this.Hide();
        }
    }
}
