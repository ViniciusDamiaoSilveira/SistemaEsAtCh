﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Admiministrador
{
    public partial class TelaEscolhaAberto : Form
    {
        public TelaEscolhaAberto()
        {
            InitializeComponent();
        }

        private void TelaEscolhaAberto_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void icone_voltar_Click(object sender, EventArgs e)
        {
            TelaChamadosInicial telachamados = new TelaChamadosInicial();
            telachamados.Show();
            this.Hide();
        }

       
    }
}
