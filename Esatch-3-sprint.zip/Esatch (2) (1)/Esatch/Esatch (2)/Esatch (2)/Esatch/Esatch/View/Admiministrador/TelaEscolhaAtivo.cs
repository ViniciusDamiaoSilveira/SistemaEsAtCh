﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Admiministrador
{
    public partial class TelaEscolhaAtivo : Form
    {
        public TelaEscolhaAtivo()
        {
            InitializeComponent();
        }

        Controller.AtivoController controlador = new Controller.AtivoController();
        private void botao_mostrar_Click(object sender, EventArgs e)
        {
            string ativo = controlador.VerificarAtivos(Txt_id.Text);
            if(ativo == "EXISTE")
            {
                TelaEditarAtivos telaeditar = new TelaEditarAtivos(Txt_id.Text);
                telaeditar.Show();
                this.Hide();
            } else
            {
                MessageBox.Show("ID do produto incorreto, tente novamente.", "ID ERRADO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TelaEscolhaAtivo_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void icone_voltar_Click(object sender, EventArgs e)
        {
            TelaAtivosInicial telainicial = new TelaAtivosInicial();
            telainicial.Show();
            this.Hide();
        }
    }
}
