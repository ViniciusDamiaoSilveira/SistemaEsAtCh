﻿
namespace Esatch.View.Chamado
{
    partial class TelaClassificar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaClassificar));
            this.Botao_classificar = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.Txt_avaliacao = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Box_nota = new System.Windows.Forms.ComboBox();
            this.Icone_voltar = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Icone_voltar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Botao_classificar
            // 
            this.Botao_classificar.BackColor = System.Drawing.Color.Orange;
            this.Botao_classificar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Botao_classificar.Font = new System.Drawing.Font("Franklin Gothic Heavy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Botao_classificar.ForeColor = System.Drawing.Color.White;
            this.Botao_classificar.Location = new System.Drawing.Point(581, 697);
            this.Botao_classificar.Name = "Botao_classificar";
            this.Botao_classificar.Size = new System.Drawing.Size(177, 35);
            this.Botao_classificar.TabIndex = 3;
            this.Botao_classificar.Text = "Classificar";
            this.Botao_classificar.UseVisualStyleBackColor = false;
            this.Botao_classificar.Click += new System.EventHandler(this.Botao_classificar_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label4.Location = new System.Drawing.Point(215, 308);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 29);
            this.label4.TabIndex = 88;
            this.label4.Text = "Avaliação";
            // 
            // Txt_avaliacao
            // 
            this.Txt_avaliacao.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Txt_avaliacao.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Txt_avaliacao.Location = new System.Drawing.Point(219, 338);
            this.Txt_avaliacao.MaxLength = 500;
            this.Txt_avaliacao.Multiline = true;
            this.Txt_avaliacao.Name = "Txt_avaliacao";
            this.Txt_avaliacao.Size = new System.Drawing.Size(539, 315);
            this.Txt_avaliacao.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label6.Location = new System.Drawing.Point(215, 207);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 29);
            this.label6.TabIndex = 90;
            this.label6.Text = "Nota";
            // 
            // Box_nota
            // 
            this.Box_nota.BackColor = System.Drawing.Color.Gainsboro;
            this.Box_nota.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Box_nota.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Box_nota.FormattingEnabled = true;
            this.Box_nota.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.Box_nota.Location = new System.Drawing.Point(219, 239);
            this.Box_nota.Name = "Box_nota";
            this.Box_nota.Size = new System.Drawing.Size(188, 29);
            this.Box_nota.TabIndex = 1;
            // 
            // Icone_voltar
            // 
            this.Icone_voltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Icone_voltar.Image = ((System.Drawing.Image)(resources.GetObject("Icone_voltar.Image")));
            this.Icone_voltar.Location = new System.Drawing.Point(10, 10);
            this.Icone_voltar.Name = "Icone_voltar";
            this.Icone_voltar.Size = new System.Drawing.Size(32, 32);
            this.Icone_voltar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Icone_voltar.TabIndex = 91;
            this.Icone_voltar.TabStop = false;
            this.Icone_voltar.Click += new System.EventHandler(this.Icone_voltar_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(449, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(101, 77);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 92;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Orange;
            this.label1.Location = new System.Drawing.Point(237, 126);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(526, 37);
            this.label1.TabIndex = 93;
            this.label1.Text = "Classifique o chamado escolhido";
            // 
            // TelaClassificar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(984, 761);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Icone_voltar);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Box_nota);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Txt_avaliacao);
            this.Controls.Add(this.Botao_classificar);
            this.MaximizeBox = false;
            this.Name = "TelaClassificar";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.TelaClassificar_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.Icone_voltar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Botao_classificar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Txt_avaliacao;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox Box_nota;
        private System.Windows.Forms.PictureBox Icone_voltar;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}