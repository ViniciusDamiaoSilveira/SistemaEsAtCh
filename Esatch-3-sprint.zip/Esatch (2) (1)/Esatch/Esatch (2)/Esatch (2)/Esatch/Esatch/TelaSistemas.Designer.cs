﻿
namespace Esatch
{
    partial class TelaSistemas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaSistemas));
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.icone_chamados = new System.Windows.Forms.PictureBox();
            this.icone_ativos = new System.Windows.Forms.PictureBox();
            this.icone_estoque = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Label_Estoque = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Icone_voltar = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.icone_chamados)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.icone_ativos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.icone_estoque)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Icone_voltar)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(409, 12);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(181, 128);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox4.TabIndex = 43;
            this.pictureBox4.TabStop = false;
            // 
            // icone_chamados
            // 
            this.icone_chamados.Cursor = System.Windows.Forms.Cursors.Hand;
            this.icone_chamados.Image = ((System.Drawing.Image)(resources.GetObject("icone_chamados.Image")));
            this.icone_chamados.Location = new System.Drawing.Point(792, 565);
            this.icone_chamados.Name = "icone_chamados";
            this.icone_chamados.Size = new System.Drawing.Size(101, 77);
            this.icone_chamados.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.icone_chamados.TabIndex = 42;
            this.icone_chamados.TabStop = false;
            this.icone_chamados.Click += new System.EventHandler(this.entrarChamados);
            // 
            // icone_ativos
            // 
            this.icone_ativos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.icone_ativos.Image = ((System.Drawing.Image)(resources.GetObject("icone_ativos.Image")));
            this.icone_ativos.Location = new System.Drawing.Point(443, 557);
            this.icone_ativos.Name = "icone_ativos";
            this.icone_ativos.Size = new System.Drawing.Size(109, 88);
            this.icone_ativos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.icone_ativos.TabIndex = 41;
            this.icone_ativos.TabStop = false;
            this.icone_ativos.Click += new System.EventHandler(this.entrarAtivos);
            // 
            // icone_estoque
            // 
            this.icone_estoque.Cursor = System.Windows.Forms.Cursors.Hand;
            this.icone_estoque.Image = ((System.Drawing.Image)(resources.GetObject("icone_estoque.Image")));
            this.icone_estoque.Location = new System.Drawing.Point(95, 565);
            this.icone_estoque.Name = "icone_estoque";
            this.icone_estoque.Size = new System.Drawing.Size(106, 78);
            this.icone_estoque.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.icone_estoque.TabIndex = 40;
            this.icone_estoque.TabStop = false;
            this.icone_estoque.Click += new System.EventHandler(this.entrarEstoques);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label7.Font = new System.Drawing.Font("Franklin Gothic Demi", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label7.Location = new System.Drawing.Point(88, 670);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 26);
            this.label7.TabIndex = 38;
            this.label7.Text = "Estoque";
            this.label7.Click += new System.EventHandler(this.entrarEstoques);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label8.Font = new System.Drawing.Font("Franklin Gothic Demi", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label8.Location = new System.Drawing.Point(784, 645);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 26);
            this.label8.TabIndex = 37;
            this.label8.Text = "Sistema de";
            this.label8.Click += new System.EventHandler(this.entrarChamados);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label5.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label5.Location = new System.Drawing.Point(784, 671);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 24);
            this.label5.TabIndex = 36;
            this.label5.Text = "Chamados";
            this.label5.Click += new System.EventHandler(this.entrarChamados);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label6.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label6.Location = new System.Drawing.Point(434, 649);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(122, 24);
            this.label6.TabIndex = 35;
            this.label6.Text = "Sistema de";
            this.label6.Click += new System.EventHandler(this.entrarAtivos);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label4.Font = new System.Drawing.Font("Franklin Gothic Demi", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label4.Location = new System.Drawing.Point(432, 673);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 26);
            this.label4.TabIndex = 34;
            this.label4.Text = "Ativos";
            this.label4.Click += new System.EventHandler(this.entrarAtivos);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label3.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label3.Location = new System.Drawing.Point(375, 332);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(275, 29);
            this.label3.TabIndex = 33;
            this.label3.Text = "qual setor deseja abrir.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label2.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label2.Location = new System.Drawing.Point(375, 303);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(260, 29);
            this.label2.TabIndex = 32;
            this.label2.Text = "Por favor, selecione a";
            // 
            // Label_Estoque
            // 
            this.Label_Estoque.AutoSize = true;
            this.Label_Estoque.BackColor = System.Drawing.Color.Transparent;
            this.Label_Estoque.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Label_Estoque.Font = new System.Drawing.Font("Franklin Gothic Demi", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label_Estoque.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.Label_Estoque.Location = new System.Drawing.Point(88, 646);
            this.Label_Estoque.Name = "Label_Estoque";
            this.Label_Estoque.Size = new System.Drawing.Size(113, 26);
            this.Label_Estoque.TabIndex = 31;
            this.Label_Estoque.Text = "Sistema de";
            this.Label_Estoque.Click += new System.EventHandler(this.entrarEstoques);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(133)))), ((int)(((byte)(36)))));
            this.label1.Location = new System.Drawing.Point(261, 201);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(468, 56);
            this.label1.TabIndex = 30;
            this.label1.Text = "Bem vindo, usuário";
            // 
            // Icone_voltar
            // 
            this.Icone_voltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Icone_voltar.Image = ((System.Drawing.Image)(resources.GetObject("Icone_voltar.Image")));
            this.Icone_voltar.Location = new System.Drawing.Point(10, 10);
            this.Icone_voltar.Name = "Icone_voltar";
            this.Icone_voltar.Size = new System.Drawing.Size(32, 32);
            this.Icone_voltar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Icone_voltar.TabIndex = 44;
            this.Icone_voltar.TabStop = false;
            this.Icone_voltar.Click += new System.EventHandler(this.Icone_voltar_Click);
            // 
            // TelaSistemas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(984, 861);
            this.Controls.Add(this.Icone_voltar);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.icone_chamados);
            this.Controls.Add(this.icone_ativos);
            this.Controls.Add(this.icone_estoque);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Label_Estoque);
            this.Controls.Add(this.label1);
            this.Name = "TelaSistemas";
            this.Text = "Tela Inicial";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.TelaSistemas_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.icone_chamados)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.icone_ativos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.icone_estoque)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Icone_voltar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox icone_chamados;
        private System.Windows.Forms.PictureBox icone_ativos;
        private System.Windows.Forms.PictureBox icone_estoque;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Label_Estoque;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox Icone_voltar;
    }
}