﻿using System;
using System.Collections.Generic;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Esatch.Model
{
    class Ativo
    {
        private string id, hardwareID, departamento, url, status;

        static string dados_conexao = "Server=10.87.100.6;Database=esatch;User id = aluno; Password=Senai1234";


        //Construtor
        public Ativo(string id, string hardwareID, string departamento, string url, string status)
        {
            this.id = id;
            this.hardwareID = hardwareID;
            this.departamento = departamento;
            this.url = url;
            this.status = status;

        }


        //GET SET
        public string Id { get => id; set => id = value; }
        public string HardwareID { get => hardwareID; set => hardwareID = value; }
        public string Departamento { get => departamento; set => departamento = value; }
        public string Url { get => url; set => url = value; }
        public string Status { get => status; set => status = value; }

        
        //Função de listar os ativos
        public static List<Ativo> ListarAtivos()
        {

            //Objeto da lista
            List<Ativo> lista = new List<Ativo>();

            MySqlConnection con = new MySqlConnection(dados_conexao);

            try
            {

                //Abrir conexão
                con.Open();

                //Utilizar o comando para selecionar todos os ativos no banco
                MySqlCommand comando = new MySqlCommand("SELECT * FROM ativos", con);

                //Objeto do leitor
                MySqlDataReader leitor = comando.ExecuteReader();
               
                //Ler todos os ativos no banco
                while (leitor.Read())
                {
                    Ativo ativo = new Ativo(
                        leitor["ID"].ToString(),
                        leitor["HardwareID"].ToString(),
                        leitor["Departamento"].ToString(),
                        leitor["URL"].ToString(),
                        TestaPing(leitor["URL"].ToString()).Result                       
                        );
                    lista.Add(ativo);
                }
                con.Close();
                return lista;

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public static async Task<string> TestaPing(string url)
        {
            try
            {
                Ping pinger = new Ping();
                PingReply resposta = await pinger.SendPingAsync(url);
                return ExibirRespostaPing(resposta);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public static string ExibirRespostaPing(PingReply resposta)
        {
            string online = resposta.ToString() == null ? "Não ativo" : "Ativo";
            return online;
        }


        //Função de adicionar ativos
        public static string AdicionarAtivos(string hardwareID, string departamento, string statusMaquina)
        {

            MySqlConnection con = new MySqlConnection(dados_conexao);

            try
            {
                //Abrir conexão
                con.Open();

                //Utilizar o comando para inserir os dados na tabela de ativos
                MySqlCommand comando = new MySqlCommand("INSERT INTO ativos(HardwareID, departamento," +
                    "StatusMaquina) VALUES" +
                    "(@hardware, @departamento, @status)", con);


                //Adicionar valores aos parâmetros
                comando.Parameters.AddWithValue("@hardware", hardwareID);
                comando.Parameters.AddWithValue("@departamento", departamento);
                comando.Parameters.AddWithValue("@status", statusMaquina);

                comando.ExecuteNonQuery();

                //Fechar conexão
                con.Close();

                return "Produto adicionado";

            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }


        //Função de verificar os ativos para selecionar
        public static string VerificarAtivos(string id)
        {
            string ativo;

            MySqlConnection con = new MySqlConnection(dados_conexao);


            try
            {
                //Abrir conexão
                con.Open();

                //Objeto do comando sql
                MySqlCommand comando = new MySqlCommand("SELECT * FROM ativos WHERE ID = @id", con);

                //Adicionando valores aos parâmetros
                comando.Parameters.AddWithValue("@id", id);

                //Objeto do leitor
                MySqlDataReader leitor = comando.ExecuteReader();

                //Verificar se existe no banco
                if (leitor.HasRows)
                {
                    ativo = "EXISTE";
                }
                else
                {
                    ativo = "FALSO";
                }

                //Fechar conexão
                con.Close();
                return ativo;

            }
            catch (Exception ex)
            {
                return ex.ToString();
            }

        }       


        public static string AtualizarAtivo(string id, string hardwareID, string departamento, string status)
        {
            //Objeto da conexão
            MySqlConnection con = new MySqlConnection(dados_conexao);

            try
            {
                //Abrir conexão
                con.Open();

                //Objeto do comando sql
                MySqlCommand comando = new MySqlCommand("UPDATE ativos SET HardwareID = @hardware," +
                   " Departamento = @departamento, StatusMaquina = @status " +
                   "WHERE ID = @id", con);


                //Adicionando valores para as variáveis
                comando.Parameters.AddWithValue("@id", id);
                comando.Parameters.AddWithValue("@hardware", hardwareID);
                comando.Parameters.AddWithValue("@departamento", departamento);
                comando.Parameters.AddWithValue("@status", status);
                
                comando.ExecuteNonQuery();

                //Fechar conexão
                con.Close();
                return "DEU CERTO";

            }
            catch (Exception ex)
            {
                return ex.ToString();
            }

        }


    }
}
