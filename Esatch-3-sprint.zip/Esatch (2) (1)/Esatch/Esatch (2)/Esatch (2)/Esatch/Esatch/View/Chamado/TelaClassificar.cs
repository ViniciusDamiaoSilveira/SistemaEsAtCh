﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Chamado
{
    public partial class TelaClassificar : Form
    {
        string codigo;
        string cpf;
        public TelaClassificar(string codigo, string cpf)
        {
            this.codigo = codigo;
            this.cpf = cpf;
            InitializeComponent();
        }

        Controller.ChamadoController controlador = new Controller.ChamadoController();

        private void TelaClassificar_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }       

        private void Icone_voltar_Click(object sender, EventArgs e) {
            TelaInicio telainicial = new TelaInicio(cpf);
            telainicial.Show();
            this.Hide();
        }

        private void Botao_classificar_Click(object sender, EventArgs e) {
            if (Txt_avaliacao.Text == "" || Box_nota.Text == "") {
                MessageBox.Show("Por favor, preencha todos os campos.", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else {
                controlador.EnviarClassificacao(codigo, Txt_avaliacao.Text, Box_nota.Text);
                MessageBox.Show("Classificação enviado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TelaInicio telainicio = new TelaInicio(cpf);
                telainicio.Show();
                this.Hide();
            }

        }
    }
}
