﻿
namespace Esatch.View.Admiministrador
{
    partial class TelaEditarAtivos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaEditarAtivos));
            this.label6 = new System.Windows.Forms.Label();
            this.Icone_voltar = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Botao_editar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Txt_status = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Txt_departamento = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Txt_hardwareID = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.Icone_voltar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.Orange;
            this.label6.Location = new System.Drawing.Point(401, 198);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(197, 37);
            this.label6.TabIndex = 84;
            this.label6.Text = "Editar Ativo";
            // 
            // Icone_voltar
            // 
            this.Icone_voltar.Image = ((System.Drawing.Image)(resources.GetObject("Icone_voltar.Image")));
            this.Icone_voltar.Location = new System.Drawing.Point(10, 10);
            this.Icone_voltar.Name = "Icone_voltar";
            this.Icone_voltar.Size = new System.Drawing.Size(32, 32);
            this.Icone_voltar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Icone_voltar.TabIndex = 85;
            this.Icone_voltar.TabStop = false;
            this.Icone_voltar.Click += new System.EventHandler(this.Icone_voltar_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(445, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(109, 88);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 86;
            this.pictureBox1.TabStop = false;
            // 
            // Botao_editar
            // 
            this.Botao_editar.BackColor = System.Drawing.Color.Orange;
            this.Botao_editar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Botao_editar.Font = new System.Drawing.Font("Franklin Gothic Heavy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Botao_editar.ForeColor = System.Drawing.Color.White;
            this.Botao_editar.Location = new System.Drawing.Point(646, 593);
            this.Botao_editar.Name = "Botao_editar";
            this.Botao_editar.Size = new System.Drawing.Size(144, 35);
            this.Botao_editar.TabIndex = 93;
            this.Botao_editar.Text = "Editar";
            this.Botao_editar.UseVisualStyleBackColor = false;
            this.Botao_editar.Click += new System.EventHandler(this.Botao_editar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label2.Location = new System.Drawing.Point(205, 485);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(188, 29);
            this.label2.TabIndex = 92;
            this.label2.Text = "Status da máquina";
            // 
            // Txt_status
            // 
            this.Txt_status.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Txt_status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Txt_status.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Txt_status.Location = new System.Drawing.Point(210, 515);
            this.Txt_status.MaxLength = 10;
            this.Txt_status.Name = "Txt_status";
            this.Txt_status.Size = new System.Drawing.Size(580, 29);
            this.Txt_status.TabIndex = 89;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label1.Location = new System.Drawing.Point(205, 395);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 29);
            this.label1.TabIndex = 91;
            this.label1.Text = "Departamento";
            // 
            // Txt_departamento
            // 
            this.Txt_departamento.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Txt_departamento.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Txt_departamento.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Txt_departamento.Location = new System.Drawing.Point(210, 425);
            this.Txt_departamento.MaxLength = 30;
            this.Txt_departamento.Name = "Txt_departamento";
            this.Txt_departamento.Size = new System.Drawing.Size(580, 29);
            this.Txt_departamento.TabIndex = 88;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label7.Location = new System.Drawing.Point(205, 305);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(127, 29);
            this.label7.TabIndex = 90;
            this.label7.Text = "Hardware ID";
            // 
            // Txt_hardwareID
            // 
            this.Txt_hardwareID.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Txt_hardwareID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Txt_hardwareID.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Txt_hardwareID.Location = new System.Drawing.Point(210, 335);
            this.Txt_hardwareID.MaxLength = 11;
            this.Txt_hardwareID.Name = "Txt_hardwareID";
            this.Txt_hardwareID.Size = new System.Drawing.Size(580, 29);
            this.Txt_hardwareID.TabIndex = 87;
            // 
            // TelaEditarAtivos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(984, 761);
            this.Controls.Add(this.Botao_editar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Txt_status);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Txt_departamento);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Txt_hardwareID);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Icone_voltar);
            this.Controls.Add(this.label6);
            this.MaximizeBox = false;
            this.Name = "TelaEditarAtivos";
            this.Text = "TelaEditarAtivos";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.TelaEditarAtivos_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.Icone_voltar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox Icone_voltar;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Botao_editar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Txt_status;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Txt_departamento;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Txt_hardwareID;
    }
}