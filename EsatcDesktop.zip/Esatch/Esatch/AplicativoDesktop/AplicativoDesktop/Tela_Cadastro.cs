﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AplicativoDesktop
{
    public partial class Tela_Cadastro : Form
    {
        private Tela_Login_ADM tela_adm;
        private Tela_Cadastro telacadastro;

        MySqlConnection conexao;
        string dados_conexao = "datasource=ESN509VMYSQL;username=aluno;password=Senai1234;database=atches";

       

        public Tela_Cadastro()
        {
            InitializeComponent();            
        }

        private void botao_cadastro_Click(object sender, EventArgs e)
        {
            conexao = new MySqlConnection(dados_conexao);
            
            //abrir try catch para conectar no banco

            try
            {
                //Abrir conexão
                conexao.Open();

                MySqlCommand comando = new MySqlCommand("INSERT INTO users VALUES (@cpf, @senha, @nome, @empresa, @departamento)", conexao);
                comando.Parameters.AddWithValue("@cpf", txt_cpf.Text);
                comando.Parameters.AddWithValue("@senha", txt_senha.Text);
                comando.Parameters.AddWithValue("@nome", txt_nome.Text);
                comando.Parameters.AddWithValue("@empresa", txt_empresa.Text);
                comando.Parameters.AddWithValue("@departamento", txt_departamento.Text);

                comando.ExecuteNonQuery();

                MessageBox.Show("Funcionou parabéns!");
            } catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            } finally
            {
                conexao.Close();
            }
        }


    }
}
