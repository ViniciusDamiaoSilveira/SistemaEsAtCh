﻿namespace Esatch.View.Estoque
{
    partial class TelaAdicionarProduto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaAdicionarProduto));
            this.label7 = new System.Windows.Forms.Label();
            this.txt_nome = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_quantidade = new System.Windows.Forms.TextBox();
            this.txt_codigo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_fornecedor = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_local = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_status = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.icone_voltar = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Botao_adicionar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.icone_voltar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label7.Location = new System.Drawing.Point(204, 340);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 29);
            this.label7.TabIndex = 48;
            this.label7.Text = "Nome";
            // 
            // txt_nome
            // 
            this.txt_nome.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_nome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_nome.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txt_nome.Location = new System.Drawing.Point(210, 370);
            this.txt_nome.MaxLength = 45;
            this.txt_nome.Name = "txt_nome";
            this.txt_nome.Size = new System.Drawing.Size(580, 29);
            this.txt_nome.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label5.Location = new System.Drawing.Point(204, 260);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 29);
            this.label5.TabIndex = 44;
            this.label5.Text = "Código";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label3.Location = new System.Drawing.Point(509, 260);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 29);
            this.label3.TabIndex = 42;
            this.label3.Text = "Quantidade";
            // 
            // txt_quantidade
            // 
            this.txt_quantidade.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_quantidade.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_quantidade.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txt_quantidade.Location = new System.Drawing.Point(516, 290);
            this.txt_quantidade.MaxLength = 20;
            this.txt_quantidade.Name = "txt_quantidade";
            this.txt_quantidade.Size = new System.Drawing.Size(274, 29);
            this.txt_quantidade.TabIndex = 2;
            // 
            // txt_codigo
            // 
            this.txt_codigo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_codigo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_codigo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txt_codigo.Location = new System.Drawing.Point(210, 290);
            this.txt_codigo.MaxLength = 11;
            this.txt_codigo.Name = "txt_codigo";
            this.txt_codigo.Size = new System.Drawing.Size(287, 29);
            this.txt_codigo.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label1.Location = new System.Drawing.Point(204, 420);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 29);
            this.label1.TabIndex = 50;
            this.label1.Text = "Fornecedor";
            // 
            // txt_fornecedor
            // 
            this.txt_fornecedor.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_fornecedor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_fornecedor.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txt_fornecedor.Location = new System.Drawing.Point(210, 450);
            this.txt_fornecedor.MaxLength = 45;
            this.txt_fornecedor.Name = "txt_fornecedor";
            this.txt_fornecedor.Size = new System.Drawing.Size(580, 29);
            this.txt_fornecedor.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label2.Location = new System.Drawing.Point(204, 500);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(221, 29);
            this.label2.TabIndex = 52;
            this.label2.Text = "Local armazenamento";
            // 
            // txt_local
            // 
            this.txt_local.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_local.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_local.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txt_local.Location = new System.Drawing.Point(210, 530);
            this.txt_local.MaxLength = 80;
            this.txt_local.Name = "txt_local";
            this.txt_local.Size = new System.Drawing.Size(580, 29);
            this.txt_local.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label4.Location = new System.Drawing.Point(204, 580);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(183, 29);
            this.label4.TabIndex = 54;
            this.label4.Text = "Status do produto";
            // 
            // txt_status
            // 
            this.txt_status.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txt_status.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txt_status.Location = new System.Drawing.Point(210, 610);
            this.txt_status.MaxLength = 20;
            this.txt_status.Name = "txt_status";
            this.txt_status.Size = new System.Drawing.Size(580, 29);
            this.txt_status.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.Orange;
            this.label6.Location = new System.Drawing.Point(352, 150);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(295, 37);
            this.label6.TabIndex = 55;
            this.label6.Text = "Adicionar Produto";
            // 
            // icone_voltar
            // 
            this.icone_voltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.icone_voltar.Image = ((System.Drawing.Image)(resources.GetObject("icone_voltar.Image")));
            this.icone_voltar.Location = new System.Drawing.Point(10, 10);
            this.icone_voltar.Name = "icone_voltar";
            this.icone_voltar.Size = new System.Drawing.Size(32, 32);
            this.icone_voltar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.icone_voltar.TabIndex = 56;
            this.icone_voltar.TabStop = false;
            this.icone_voltar.Click += new System.EventHandler(this.icone_voltar_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(447, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(106, 78);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 57;
            this.pictureBox1.TabStop = false;
            // 
            // Botao_adicionar
            // 
            this.Botao_adicionar.BackColor = System.Drawing.Color.Orange;
            this.Botao_adicionar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Botao_adicionar.Font = new System.Drawing.Font("Franklin Gothic Heavy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Botao_adicionar.ForeColor = System.Drawing.Color.White;
            this.Botao_adicionar.Location = new System.Drawing.Point(646, 680);
            this.Botao_adicionar.Name = "Botao_adicionar";
            this.Botao_adicionar.Size = new System.Drawing.Size(144, 35);
            this.Botao_adicionar.TabIndex = 58;
            this.Botao_adicionar.Text = "Adicionar";
            this.Botao_adicionar.UseVisualStyleBackColor = false;
            this.Botao_adicionar.Click += new System.EventHandler(this.Botao_adicionar_Click);
            // 
            // TelaAdicionarProduto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(984, 761);
            this.Controls.Add(this.Botao_adicionar);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.icone_voltar);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_status);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_local);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_fornecedor);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_nome);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_quantidade);
            this.Controls.Add(this.txt_codigo);
            this.MaximizeBox = false;
            this.Name = "TelaAdicionarProduto";
            this.Text = "TelaAdicionarProduto";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FecharPrograma);
            ((System.ComponentModel.ISupportInitialize)(this.icone_voltar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_nome;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_quantidade;
        private System.Windows.Forms.TextBox txt_codigo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_fornecedor;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_local;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_status;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox icone_voltar;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Botao_adicionar;
    }
}