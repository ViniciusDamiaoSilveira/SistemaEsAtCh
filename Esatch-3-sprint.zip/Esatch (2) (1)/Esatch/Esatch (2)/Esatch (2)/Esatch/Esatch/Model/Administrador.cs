﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data.MySqlClient;

namespace Esatch.Model
{
    class Administrador
    {
        static string dados_conexao = "Server=10.87.100.6;Database=esatch;User id = aluno; Password=Senai1234";
        private string codigo, nome, cpf, departamento;


        //Construtor
        public Administrador(string codigo, string nome, string cpf, string departamento)
        {
            this.Codigo = codigo;
            this.nome = nome;
            this.cpf = cpf;
            this.departamento = departamento;
        }


        //GET SET
        public string Codigo { get => codigo; set => codigo = value; }
        public string Nome { get => nome; set => nome = value; }
        public string Cpf { get => cpf; set => cpf = value; }
        public string Departamento { get => departamento; set => departamento = value; }


        //Função de login do ADM
        public static string EntrarADM(string codigo)
        {

            string adm;

            MySqlConnection con = new MySqlConnection(dados_conexao);

            try
            {
                //Abrir a conexão
                con.Open();

                //Utilizar o comando para verificação do login do Administrador
                MySqlCommand comando = new MySqlCommand("SELECT * FROM admin WHERE codigo_admin = @codigo_admin", con);

                //Adicionar valores aos parâmetros
                comando.Parameters.AddWithValue("@codigo_admin", codigo);

                //Criar o leitor
                MySqlDataReader leitor = comando.ExecuteReader();

                //Verificar se existe no banco
                if(leitor.HasRows)
                {
                    adm = "EXISTE";
                } else
                {
                    adm = "NÃO";
                }


                //Fechar conexão
                con.Close();

                //Retornar o valor do resultado
                return adm;


            }
            catch (Exception ex)
            {
                //Mostrar o erro
                return ex.ToString();
            }
        }


        //Função de cadastro de usuário
        public static string CadastrarUsuario(string cpf, string senha) 
        {
            
            MySqlConnection con = new MySqlConnection(dados_conexao);

            try {
                //Abrir a conexão
                con.Open();

                //Utilizar o comando para o cadastro do usuário
                MySqlCommand comando = new MySqlCommand("INSERT INTO usuarios(cpf, senha)" +
                    " VALUES" +
                    " (@cpf, @senha) ", con);

                //Adicionar valores aos parâmetros
                comando.Parameters.AddWithValue("@cpf", cpf);
                comando.Parameters.AddWithValue("@senha", senha);

                comando.ExecuteNonQuery();

                //Fechar conexão
                con.Close();
                return "Usuário cadastrado";


            } 
            catch (Exception ex) 
            {
                //Mostrar o erro
                return ex.ToString();
            }
        }







    }   
        
}
