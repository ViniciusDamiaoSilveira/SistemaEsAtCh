﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data.MySqlClient;

namespace Esatch.Model
{
    class Usuario
    {
        static string dados_conexao = "Server=10.87.100.6;Database=esatch;User id = aluno; Password=Senai1234";
        private string cpf, senha;

        public Usuario(string cpf, string senha) {
            this.cpf = cpf;
            this.senha = senha;
        }

        public string Cpf { get => cpf; set => cpf = value; }
        public string Senha { get => senha; set => senha = value; }

        public static string EntrarUsuario(string cpf, string senha) {
            //Objeto da conexão
            MySqlConnection con = new MySqlConnection(dados_conexao);
            string statusLogin;

            try {
                //Abrir conexão
                con.Open();

                //Objeto do comando para o sql
                MySqlCommand comando = new MySqlCommand("SELECT * FROM usuarios WHERE cpf = @cpf and senha = @senha", con);

                //Adicionar valores para as variáveis
                comando.Parameters.AddWithValue("@cpf", cpf);
                comando.Parameters.AddWithValue("@senha", senha);

                //Objeto Leitor
                MySqlDataReader leitor = comando.ExecuteReader();

                //Verificar se existe no banco
                if (leitor.HasRows) {
                    statusLogin = "EXISTE";
                } else {
                    statusLogin = "FALSO";
                }

                //Fechar conexão
                con.Close();

                return statusLogin;

            } catch (Exception ex) {
                return ex.ToString();
            }
        }
    }      
}

