﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplicativoDesktop
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void botao_cadastro_Click(object sender, EventArgs e)
        {
            Tela_Login_ADM tela_Adm = new Tela_Login_ADM(this);
            tela_Adm.Show();
            this.Visible = false;
        }

        private void botao_entrar_Click(object sender, EventArgs e)
        {
            Tela_Login_Usuario tela_login_usuario = new Tela_Login_Usuario(this);
            tela_login_usuario.Show();
            this.Visible = false;
        }
    }
}
