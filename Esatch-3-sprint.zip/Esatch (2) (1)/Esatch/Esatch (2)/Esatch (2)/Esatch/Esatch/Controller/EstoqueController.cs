﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Esatch.Controller
{
    class EstoqueController
    {
        internal List<Model.Estoque> ListarEstoque()
        {
            return Model.Estoque.MostrarEstoque();
        }

        internal void AdicionarEstoque(string codigo, string nome, string quantidade, string status, string local, string vendedor)
        {
            Model.Estoque.AdicionarProduto(codigo, nome, quantidade, status, local, vendedor);
        }

        public string VerificarProduto(string id) {
            string status = Model.Estoque.VerificarProduto(id);
            return status;
        }

        internal List<Model.Estoque> MostrarProdutoID(string id)
        {
          return Model.Estoque.MostrarProdutoID(id);
        }

        internal void AtualizarProduto(string id, string codigo, string nome, string quantidade, string status, string local, string vendedor) {
            Model.Estoque.AtualizarProduto(id, codigo, nome, quantidade, status, local, vendedor);
        }

        
    }
}
