﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Admiministrador
{
    public partial class TelaEditarAtivos : Form
    {
        string id;
        public TelaEditarAtivos(string id)
        {
            this.id = id;
            InitializeComponent();
        }

        Controller.AtivoController controlador = new Controller.AtivoController();

        private void TelaEditarAtivos_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

       /* private void TelaEditarAtivos_Load(object sender, EventArgs e)
        {
            List<Model.Ativo> lista = controlador.MostrarAtivo(id);
            foreach (Model.Ativo ativo in lista)
            {
                Txt_hardwareID.Text = ativo.HardwareID;
                Txt_departamento.Text = ativo.Departamento;
                Txt_status.Text = ativo.Status;
            }
        }*/

        private void Botao_editar_Click(object sender, EventArgs e)
        {
            if(Txt_departamento.Text == "" || Txt_hardwareID.Text == "" || Txt_status.Text == "")
            {
                MessageBox.Show("Por favor, preencha todos os campos", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                controlador.AtualizarAtivo(id, Txt_hardwareID.Text, Txt_departamento.Text, Txt_status.Text);
                MessageBox.Show("Ativo atualizado com sucesso", "Atualizado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TelaInicial telainicial = new TelaInicial();
                telainicial.Show();
                this.Hide();

            }
        }

        private void Icone_voltar_Click(object sender, EventArgs e)
        {
            TelaAtivosInicial telaativos = new TelaAtivosInicial();
            telaativos.Show();
            this.Hide();
        }   
    }
}
