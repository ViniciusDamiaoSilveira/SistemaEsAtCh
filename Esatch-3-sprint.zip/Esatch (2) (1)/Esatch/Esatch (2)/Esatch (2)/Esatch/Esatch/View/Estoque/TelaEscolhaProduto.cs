﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Estoque
{
    public partial class TelaEscolhaProduto : Form
    {
        string cpf;
        public TelaEscolhaProduto()
        {
            InitializeComponent();
        }

        Controller.EstoqueController controlador = new Controller.EstoqueController();

        

        private void TelaEscolhaProduto_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void icone_voltar_Click(object sender, EventArgs e) {
            TelaInicial telainicial = new TelaInicial(cpf);
            telainicial.Show();
            this.Hide();
        }

        private void botao_mostrar_Click(object sender, EventArgs e) {
            string status = controlador.VerificarProduto(txt_id.Text);
            if(status == "EXISTE") {
                TelaEditarProduto telaeditar = new TelaEditarProduto(txt_id.Text);
                telaeditar.Show();
                this.Hide();
            } else {
                MessageBox.Show("ID do produto incorreto, tente novamente.", "ID ERRADO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
