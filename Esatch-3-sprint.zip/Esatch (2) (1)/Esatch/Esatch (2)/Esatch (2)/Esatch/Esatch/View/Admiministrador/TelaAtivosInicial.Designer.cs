﻿
namespace Esatch.View.Admiministrador
{
    partial class TelaAtivosInicial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaAtivosInicial));
            this.icone_voltar = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.botao_adicionar = new System.Windows.Forms.Button();
            this.Icone_atualizar = new System.Windows.Forms.PictureBox();
            this.List_ativos = new System.Windows.Forms.ListView();
            this.ID = new System.Windows.Forms.ColumnHeader();
            this.HardwareID = new System.Windows.Forms.ColumnHeader();
            this.Departamento = new System.Windows.Forms.ColumnHeader();
            this.Status = new System.Windows.Forms.ColumnHeader();
            this.botao_editar = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.icone_voltar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Icone_atualizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // icone_voltar
            // 
            this.icone_voltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.icone_voltar.Location = new System.Drawing.Point(10, 10);
            this.icone_voltar.Name = "icone_voltar";
            this.icone_voltar.Size = new System.Drawing.Size(32, 32);
            this.icone_voltar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.icone_voltar.TabIndex = 45;
            this.icone_voltar.TabStop = false;
            this.icone_voltar.Click += new System.EventHandler(this.icone_voltar_Click);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label2.Location = new System.Drawing.Point(1620, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(273, 32);
            this.label2.TabIndex = 43;
            this.label2.Text = "Bem vindo, usuário";
            // 
            // botao_adicionar
            // 
            this.botao_adicionar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.botao_adicionar.BackColor = System.Drawing.Color.Orange;
            this.botao_adicionar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.botao_adicionar.Font = new System.Drawing.Font("Franklin Gothic Heavy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.botao_adicionar.ForeColor = System.Drawing.Color.White;
            this.botao_adicionar.Location = new System.Drawing.Point(861, 916);
            this.botao_adicionar.Name = "botao_adicionar";
            this.botao_adicionar.Size = new System.Drawing.Size(198, 35);
            this.botao_adicionar.TabIndex = 46;
            this.botao_adicionar.Text = "Adicionar Ativos";
            this.botao_adicionar.UseVisualStyleBackColor = false;
            this.botao_adicionar.Click += new System.EventHandler(this.botao_adicionar_Click);
            // 
            // Icone_atualizar
            // 
            this.Icone_atualizar.Image = ((System.Drawing.Image)(resources.GetObject("Icone_atualizar.Image")));
            this.Icone_atualizar.Location = new System.Drawing.Point(1584, 835);
            this.Icone_atualizar.Name = "Icone_atualizar";
            this.Icone_atualizar.Size = new System.Drawing.Size(32, 32);
            this.Icone_atualizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Icone_atualizar.TabIndex = 47;
            this.Icone_atualizar.TabStop = false;
            this.Icone_atualizar.Click += new System.EventHandler(this.Icone_atualizar_Click);
            // 
            // List_ativos
            // 
            this.List_ativos.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.List_ativos.Alignment = System.Windows.Forms.ListViewAlignment.Default;
            this.List_ativos.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.List_ativos.BackColor = System.Drawing.Color.Gainsboro;
            this.List_ativos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.List_ativos.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ID,
            this.HardwareID,
            this.Departamento,
            this.Status});
            this.List_ativos.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.List_ativos.ForeColor = System.Drawing.Color.Black;
            this.List_ativos.GridLines = true;
            this.List_ativos.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.List_ativos.HideSelection = false;
            this.List_ativos.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.List_ativos.Location = new System.Drawing.Point(360, 202);
            this.List_ativos.Name = "List_ativos";
            this.List_ativos.Size = new System.Drawing.Size(1200, 676);
            this.List_ativos.TabIndex = 48;
            this.List_ativos.UseCompatibleStateImageBehavior = false;
            this.List_ativos.View = System.Windows.Forms.View.Details;
            // 
            // ID
            // 
            this.ID.Text = "ID";
            this.ID.Width = 150;
            // 
            // HardwareID
            // 
            this.HardwareID.Text = "Hardware ID";
            this.HardwareID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.HardwareID.Width = 400;
            // 
            // Departamento
            // 
            this.Departamento.Text = "Departamento";
            this.Departamento.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Departamento.Width = 350;
            // 
            // Status
            // 
            this.Status.Text = "Status";
            this.Status.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Status.Width = 300;
            // 
            // botao_editar
            // 
            this.botao_editar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.botao_editar.BackColor = System.Drawing.Color.Orange;
            this.botao_editar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.botao_editar.Font = new System.Drawing.Font("Franklin Gothic Heavy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.botao_editar.ForeColor = System.Drawing.Color.White;
            this.botao_editar.Location = new System.Drawing.Point(861, 977);
            this.botao_editar.Name = "botao_editar";
            this.botao_editar.Size = new System.Drawing.Size(198, 35);
            this.botao_editar.TabIndex = 49;
            this.botao_editar.Text = "Editar Ativos";
            this.botao_editar.UseVisualStyleBackColor = false;
            this.botao_editar.Click += new System.EventHandler(this.botao_editar_Click);
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.Orange;
            this.label6.Location = new System.Drawing.Point(824, 138);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(271, 37);
            this.label6.TabIndex = 89;
            this.label6.Text = "Visualizar ativos";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(907, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(109, 88);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 90;
            this.pictureBox1.TabStop = false;
            // 
            // TelaAtivosInicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1904, 1041);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.botao_editar);
            this.Controls.Add(this.List_ativos);
            this.Controls.Add(this.Icone_atualizar);
            this.Controls.Add(this.botao_adicionar);
            this.Controls.Add(this.icone_voltar);
            this.Controls.Add(this.label2);
            this.MaximizeBox = false;
            this.Name = "TelaAtivosInicial";
            this.Text = "TelaAtivosInicial";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.TelaAtivosInicial_FormClosed);
            this.Load += new System.EventHandler(this.TelaAtivosInicial_Load);
            ((System.ComponentModel.ISupportInitialize)(this.icone_voltar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Icone_atualizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox icone_voltar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button botao_adicionar;
        private System.Windows.Forms.PictureBox Icone_atualizar;
        private System.Windows.Forms.ListView List_ativos;
        private System.Windows.Forms.ColumnHeader ID;
        private System.Windows.Forms.ColumnHeader HardwareID;
        private System.Windows.Forms.ColumnHeader Departamento;
        private System.Windows.Forms.ColumnHeader Status;
        private System.Windows.Forms.Button botao_editar;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}