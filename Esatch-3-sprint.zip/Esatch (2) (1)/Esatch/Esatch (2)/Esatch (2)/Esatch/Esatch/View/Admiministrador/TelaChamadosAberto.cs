﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Admiministrador
{
    public partial class TelaChamadosAberto : Form
    {
        public TelaChamadosAberto()
        {
            InitializeComponent();
        }

        Controller.ChamadoController controlador = new Controller.ChamadoController();

        private void TelaChamadosInicial_Load(object sender, EventArgs e)
        {
            List<Model.Chamado> lista = controlador.ListarChamadosAberto();

            foreach (Model.Chamado chamado in lista)
            {
                ListViewItem linha = new ListViewItem();
                linha.Text = chamado.Codigo;
                linha.SubItems.Add(chamado.Titulo);
                linha.SubItems.Add(chamado.Status);
                linha.SubItems.Add(chamado.Prioridade);
                list_chamados.Items.Add(linha);
            }
        }

        private void Icone_voltar_Click(object sender, EventArgs e)
        {
            TelaChamadosInicial telainicial = new TelaChamadosInicial();
            telainicial.Show();
            this.Hide();
        }

        private void icone_atualizar_Click(object sender, EventArgs e)
        {

            list_chamados.Items.Clear();

            List<Model.Chamado> lista = controlador.ListarChamadosAberto();

            foreach (Model.Chamado chamado in lista)
            {
                ListViewItem linha = new ListViewItem();
                linha.Text = chamado.Codigo;
                linha.SubItems.Add(chamado.Titulo);
                linha.SubItems.Add(chamado.Status);
                linha.SubItems.Add(chamado.Prioridade);
                list_chamados.Items.Add(linha);
            }
        }

        private void TelaChamadosAberto_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
