﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Admiministrador
{
    public partial class TelaInicial : Form
    {
        string cpf;
        public TelaInicial()
        {
            InitializeComponent();
        }

        private void TelaInicial_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void entrarAtivos(object sender, EventArgs e)
        {
            TelaAtivosInicial telaativos = new TelaAtivosInicial();
            telaativos.Show();
            this.Hide();
        }

        private void entrarChamados(object sender, EventArgs e)
        {
            TelaChamadosInicial telachamados = new TelaChamadosInicial();
            telachamados.Show();
            this.Hide();
        }

        private void entrarEstoque(object sender, EventArgs e)
        {

        }

        private void Icone_voltar_Click(object sender, EventArgs e)
        {
            TelaSistemas telasistemas = new TelaSistemas(cpf);
            telasistemas.Show();
            this.Hide();
        }

        private void botao_cadastrar_Click(object sender, EventArgs e)
        {
            TelaCadastrarUsuario telacadastrar = new TelaCadastrarUsuario();
            telacadastrar.Show();
            this.Hide();
        }
    }
}
