﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Chamado
{
    public partial class TelaEnviarChamado : Form
    {
        string cpf;
        public TelaEnviarChamado(string cpf)
        {
            this.cpf = cpf;
            InitializeComponent();
        }

        Controller.ChamadoController controlador = new Controller.ChamadoController();

        
        private void TelaEnviarChamado_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void Botao_solicitar_Click(object sender, EventArgs e) {
            if (Txt_departamento.Text == "" || Txt_descricao.Text == "" || Txt_titulo.Text == "" || Box_prioridade.Text == "") {
                MessageBox.Show("Por favor, preencha todos os campos.", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else {
                controlador.SolicitarChamado(Txt_titulo.Text, Box_prioridade.Text,
                Txt_departamento.Text, Txt_descricao.Text, cpf);
                MessageBox.Show("Chamado enviado com sucesso.", "Enviado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TelaInicio telainicial = new TelaInicio(cpf);
                telainicial.Show();
                this.Hide();
            }
        }

        private void Icone_voltar_Click(object sender, EventArgs e) {
            TelaInicio telainicial = new TelaInicio(cpf);
            telainicial.Show();
            this.Hide();
        }
    }
}
