﻿using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data.MySqlClient;

namespace Esatch.Model
{
    class Chamado
    {
        static string dados_conexao = "Server=10.87.100.6;Database=esatch;User id = aluno; Password=Senai1234";
        private string codigo, titulo, status, prioridade;

        public Chamado(string codigo, string titulo, string status, string prioridade)
        {
            this.codigo = codigo;
            this.titulo = titulo;
            this.status = status;
            this.prioridade = prioridade;
        }

        public string Codigo { get => codigo; set => codigo = value; }
        public string Titulo { get => titulo; set => titulo = value; }
        public string Status { get => status; set => status = value; }
        public string Prioridade { get => prioridade; set => prioridade = value; }


        public static string EnviarChamados(string titulo, string prioridade,
        string departamento, string descricao, string cpf)
        {
            //Objeto da conexão
            MySqlConnection con = new MySqlConnection(dados_conexao);

            try
            {
                //Abrir conexão
                con.Open();

                //Objeto do comando para o sql
                MySqlCommand comando = new MySqlCommand("INSERT INTO chamados(titulo_chamados, prioridade_chamados," +
                    " departamento_chamados, descricao_chamados, cpf, status)" +
                    " VALUES (@titulo, @prioridade, @departamento," +
                    "@descricao, @cpf, @status)", con);

                //Adicionar valores para as variáveis
                comando.Parameters.AddWithValue("@titulo", titulo);
                comando.Parameters.AddWithValue("@prioridade", prioridade);
                comando.Parameters.AddWithValue("@departamento", departamento);
                comando.Parameters.AddWithValue("@descricao", descricao);
                comando.Parameters.AddWithValue("@cpf", cpf);
                comando.Parameters.AddWithValue("@status", "Em aberto");

                comando.ExecuteNonQuery();

                //Fechar conexão
                con.Close();

                return "DEU CERTO!";
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }

        }       

        public static List<Chamado> ListarChamados(string cpf)
        {
            //Objeto da lista
            List<Chamado> lista = new List<Chamado>();

            MySqlConnection con = new MySqlConnection(dados_conexao);

            try
            {

                //Abrir conexão
                con.Open();
                MySqlCommand comando = new MySqlCommand("SELECT * FROM chamados WHERE cpf = @cpf", con);

                //Adicionar valor aos parametros
                comando.Parameters.AddWithValue("@cpf", cpf);

                MySqlDataReader leitor = comando.ExecuteReader();

                while (leitor.Read())
                {
                    Chamado chamado = new Chamado(
                        leitor["codigo_chamados"].ToString(),
                        leitor["titulo_chamados"].ToString(),
                        leitor["status"].ToString(),
                        leitor["prioridade_chamados"].ToString());
                    lista.Add(chamado);
                }
                con.Close();
                return lista;

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public static List<Chamado> ListarChamadosAberto()
        {
            //Objeto da lista
            List<Chamado> lista = new List<Chamado>();

            MySqlConnection con = new MySqlConnection(dados_conexao);

            try
            {

                //Abrir conexão
                con.Open();
                MySqlCommand comando = new MySqlCommand("SELECT * FROM chamados WHERE status = @status", con);

                //Adicionar valor para os parametros
                comando.Parameters.AddWithValue("@status", "Em aberto");

                MySqlDataReader leitor = comando.ExecuteReader();

                while (leitor.Read())
                {
                    Chamado chamado = new Chamado(
                        leitor["codigo_chamados"].ToString(),
                        leitor["titulo_chamados"].ToString(),
                        leitor["status"].ToString(),
                        leitor["prioridade_chamados"].ToString());
                    lista.Add(chamado);
                }
                con.Close();
                return lista;

            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public static List<Chamado> ListarChamadosFechados()
        {
            //Objeto da lista
            List<Chamado> lista = new List<Chamado>();

            MySqlConnection con = new MySqlConnection(dados_conexao);

            try
            {

                //Abrir conexão
                con.Open();
                MySqlCommand comando = new MySqlCommand("SELECT * FROM chamados WHERE status = @status", con);

                //Adicionar valor para os parametros
                comando.Parameters.AddWithValue("@status", "Fechado");

                MySqlDataReader leitor = comando.ExecuteReader();

                while (leitor.Read())
                {
                    Chamado chamado = new Chamado(
                        leitor["codigo_chamados"].ToString(),
                        leitor["titulo_chamados"].ToString(),
                        leitor["status"].ToString(),
                        leitor["prioridade_chamados"].ToString());
                    lista.Add(chamado);
                }
                con.Close();
                return lista;

            }
            catch (Exception ex)
            {
                return null;
            }
        }


        public static string VerificarChamado(string codigo, string cpf)
        {
            //Objeto da conexão
            MySqlConnection con = new MySqlConnection(dados_conexao);

            string status;

            try
            {
                //Abrir conexão
                con.Open();

                //Objeto do comando sql
                MySqlCommand comando = new MySqlCommand("SELECT * FROM chamados WHERE codigo_chamados = @codigo AND cpf = @cpf AND status = @status", con);

                //Adicionando valores para as variáveis
                comando.Parameters.AddWithValue("@codigo", codigo);
                comando.Parameters.AddWithValue("@cpf", cpf);
                comando.Parameters.AddWithValue("@status", "Em aberto");

                //Objeto do leitor
                MySqlDataReader leitor = comando.ExecuteReader();

                //Verificar se existe no banco
                if (leitor.HasRows)
                {
                    status = "EXISTE";
                }
                else
                {
                    status = "FALSO";
                }

                //Fechar conexão
                con.Close();
                return status;

            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }


        public static string EnviarClassificacao(string codigo, string avaliacao, string nota)
        {
            //Objeto da conexão
            MySqlConnection con = new MySqlConnection(dados_conexao);

            try
            {
                //Abrir conexão
                con.Open();

                //Objeto do comando sql
                MySqlCommand comando = new MySqlCommand("UPDATE chamados SET status = @status, avaliacao = @avaliacao, nota = @nota WHERE codigo_chamados = @codigo", con);


                //Adicionando valores para as variáveis
                comando.Parameters.AddWithValue("@codigo", codigo);
                comando.Parameters.AddWithValue("@status", "Fechado");
                comando.Parameters.AddWithValue("@avaliacao", avaliacao);
                comando.Parameters.AddWithValue("@nota", nota);

                comando.ExecuteNonQuery();

                //Fechar conexão
                con.Close();
                return "DEU CERTO";

            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }

    }
}
