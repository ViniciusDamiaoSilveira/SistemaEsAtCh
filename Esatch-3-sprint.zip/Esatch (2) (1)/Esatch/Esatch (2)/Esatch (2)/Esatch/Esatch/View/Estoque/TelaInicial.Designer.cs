﻿
namespace Esatch.View.Estoque
{
    partial class TelaInicial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaInicial));
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.botao_relatorio = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader5 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader6 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader7 = new System.Windows.Forms.ColumnHeader();
            this.botao_relatori = new System.Windows.Forms.Button();
            this.botao_adicionar = new System.Windows.Forms.Button();
            this.list_estoque = new System.Windows.Forms.ListView();
            this.ID = new System.Windows.Forms.ColumnHeader();
            this.Codigo = new System.Windows.Forms.ColumnHeader();
            this.NomeMP = new System.Windows.Forms.ColumnHeader();
            this.Quantidade = new System.Windows.Forms.ColumnHeader();
            this.LocalArmazenamento = new System.Windows.Forms.ColumnHeader();
            this.Distribuidor = new System.Windows.Forms.ColumnHeader();
            this.Status = new System.Windows.Forms.ColumnHeader();
            this.icone_voltar = new System.Windows.Forms.PictureBox();
            this.icone_atualizar = new System.Windows.Forms.PictureBox();
            this.botao_editar = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.icone_voltar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.icone_atualizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.label2.Location = new System.Drawing.Point(1619, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(273, 32);
            this.label2.TabIndex = 6;
            this.label2.Text = "Bem vindo, usuário";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Orange;
            this.label1.Location = new System.Drawing.Point(504, 1050);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(391, 37);
            this.label1.TabIndex = 7;
            this.label1.Text = "Visualização de Estoque";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.Orange;
            this.label3.Location = new System.Drawing.Point(751, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(391, 37);
            this.label3.TabIndex = 8;
            this.label3.Text = "Visualização de Estoque";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Orange;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Franklin Gothic Heavy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(776, 838);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(215, 35);
            this.button2.TabIndex = 12;
            this.button2.Text = "Adicionar Item";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // botao_relatorio
            // 
            this.botao_relatorio.BackColor = System.Drawing.Color.Orange;
            this.botao_relatorio.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.botao_relatorio.Font = new System.Drawing.Font("Franklin Gothic Heavy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.botao_relatorio.ForeColor = System.Drawing.Color.White;
            this.botao_relatorio.Location = new System.Drawing.Point(809, 779);
            this.botao_relatorio.Name = "botao_relatorio";
            this.botao_relatorio.Size = new System.Drawing.Size(150, 35);
            this.botao_relatorio.TabIndex = 11;
            this.botao_relatorio.Text = "Relatório";
            this.botao_relatorio.UseVisualStyleBackColor = false;
            // 
            // listView1
            // 
            this.listView1.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.listView1.Alignment = System.Windows.Forms.ListViewAlignment.Default;
            this.listView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7});
            this.listView1.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.listView1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.listView1.GridLines = true;
            this.listView1.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listView1.HideSelection = false;
            this.listView1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.listView1.Location = new System.Drawing.Point(299, 167);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(1306, 575);
            this.listView1.TabIndex = 10;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "ID";
            this.columnHeader1.Width = 100;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Código";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader2.Width = 150;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Matéria Prima";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader3.Width = 250;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Quantidade";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader4.Width = 150;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Local Armazenamento";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader5.Width = 250;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Distribuidor";
            this.columnHeader6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader6.Width = 200;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Status";
            this.columnHeader7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader7.Width = 200;
            // 
            // botao_relatori
            // 
            this.botao_relatori.BackColor = System.Drawing.Color.Orange;
            this.botao_relatori.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.botao_relatori.Font = new System.Drawing.Font("Franklin Gothic Heavy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.botao_relatori.ForeColor = System.Drawing.Color.White;
            this.botao_relatori.Location = new System.Drawing.Point(885, 845);
            this.botao_relatori.Name = "botao_relatori";
            this.botao_relatori.Size = new System.Drawing.Size(215, 35);
            this.botao_relatori.TabIndex = 9;
            this.botao_relatori.Text = "Relatório";
            this.botao_relatori.UseVisualStyleBackColor = false;
            this.botao_relatori.Click += new System.EventHandler(this.botao_relatori_Click);
            // 
            // botao_adicionar
            // 
            this.botao_adicionar.BackColor = System.Drawing.Color.Orange;
            this.botao_adicionar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.botao_adicionar.Font = new System.Drawing.Font("Franklin Gothic Heavy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.botao_adicionar.ForeColor = System.Drawing.Color.White;
            this.botao_adicionar.Location = new System.Drawing.Point(885, 901);
            this.botao_adicionar.Name = "botao_adicionar";
            this.botao_adicionar.Size = new System.Drawing.Size(215, 35);
            this.botao_adicionar.TabIndex = 10;
            this.botao_adicionar.Text = "Adicionar Produto";
            this.botao_adicionar.UseVisualStyleBackColor = false;
            this.botao_adicionar.Click += new System.EventHandler(this.botao_adicionar_Click);
            // 
            // list_estoque
            // 
            this.list_estoque.Activation = System.Windows.Forms.ItemActivation.OneClick;
            this.list_estoque.Alignment = System.Windows.Forms.ListViewAlignment.Default;
            this.list_estoque.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.list_estoque.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ID,
            this.Codigo,
            this.NomeMP,
            this.Quantidade,
            this.LocalArmazenamento,
            this.Distribuidor,
            this.Status});
            this.list_estoque.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.list_estoque.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(84)))), ((int)(((byte)(120)))));
            this.list_estoque.GridLines = true;
            this.list_estoque.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.list_estoque.HideSelection = false;
            this.list_estoque.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.list_estoque.Location = new System.Drawing.Point(299, 233);
            this.list_estoque.Name = "list_estoque";
            this.list_estoque.Size = new System.Drawing.Size(1280, 594);
            this.list_estoque.TabIndex = 11;
            this.list_estoque.UseCompatibleStateImageBehavior = false;
            this.list_estoque.View = System.Windows.Forms.View.Details;
            // 
            // ID
            // 
            this.ID.Text = "ID";
            this.ID.Width = 100;
            // 
            // Codigo
            // 
            this.Codigo.Text = "Código";
            this.Codigo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Codigo.Width = 150;
            // 
            // NomeMP
            // 
            this.NomeMP.Text = "Produto";
            this.NomeMP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NomeMP.Width = 250;
            // 
            // Quantidade
            // 
            this.Quantidade.Text = "Quantidade";
            this.Quantidade.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Quantidade.Width = 150;
            // 
            // LocalArmazenamento
            // 
            this.LocalArmazenamento.Text = "Local Armazenamento";
            this.LocalArmazenamento.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.LocalArmazenamento.Width = 250;
            // 
            // Distribuidor
            // 
            this.Distribuidor.Text = "Distribuidor";
            this.Distribuidor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Distribuidor.Width = 200;
            // 
            // Status
            // 
            this.Status.Text = "Status";
            this.Status.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Status.Width = 200;
            // 
            // icone_voltar
            // 
            this.icone_voltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.icone_voltar.Image = ((System.Drawing.Image)(resources.GetObject("icone_voltar.Image")));
            this.icone_voltar.Location = new System.Drawing.Point(10, 10);
            this.icone_voltar.Name = "icone_voltar";
            this.icone_voltar.Size = new System.Drawing.Size(32, 32);
            this.icone_voltar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.icone_voltar.TabIndex = 40;
            this.icone_voltar.TabStop = false;
            this.icone_voltar.Click += new System.EventHandler(this.icone_voltar_Click);
            // 
            // icone_atualizar
            // 
            this.icone_atualizar.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.icone_atualizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.icone_atualizar.Image = ((System.Drawing.Image)(resources.GetObject("icone_atualizar.Image")));
            this.icone_atualizar.Location = new System.Drawing.Point(1634, 772);
            this.icone_atualizar.Name = "icone_atualizar";
            this.icone_atualizar.Size = new System.Drawing.Size(32, 32);
            this.icone_atualizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.icone_atualizar.TabIndex = 41;
            this.icone_atualizar.TabStop = false;
            this.icone_atualizar.Click += new System.EventHandler(this.icone_atualizar_Click);
            // 
            // botao_editar
            // 
            this.botao_editar.BackColor = System.Drawing.Color.Orange;
            this.botao_editar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.botao_editar.Font = new System.Drawing.Font("Franklin Gothic Heavy", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.botao_editar.ForeColor = System.Drawing.Color.White;
            this.botao_editar.Location = new System.Drawing.Point(885, 951);
            this.botao_editar.Name = "botao_editar";
            this.botao_editar.Size = new System.Drawing.Size(215, 35);
            this.botao_editar.TabIndex = 42;
            this.botao_editar.Text = "Editar Produto";
            this.botao_editar.UseVisualStyleBackColor = false;
            this.botao_editar.Click += new System.EventHandler(this.botao_editar_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(896, 26);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(106, 78);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 43;
            this.pictureBox2.TabStop = false;
            // 
            // TelaInicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1904, 1041);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.botao_editar);
            this.Controls.Add(this.icone_atualizar);
            this.Controls.Add(this.icone_voltar);
            this.Controls.Add(this.list_estoque);
            this.Controls.Add(this.botao_adicionar);
            this.Controls.Add(this.botao_relatori);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.MaximizeBox = false;
            this.Name = "TelaInicial";
            this.Text = "TelaInicial";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.fecharPrograma);
            this.Load += new System.EventHandler(this.mostrarEstoque);
            ((System.ComponentModel.ISupportInitialize)(this.icone_voltar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.icone_atualizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button botao_relatorio;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.Button botao_relatori;
        private System.Windows.Forms.Button botao_adicionar;
        private System.Windows.Forms.ListView list_estoque;
        private System.Windows.Forms.ColumnHeader ID;
        private System.Windows.Forms.ColumnHeader Codigo;
        private System.Windows.Forms.ColumnHeader NomeMP;
        private System.Windows.Forms.ColumnHeader Quantidade;
        private System.Windows.Forms.ColumnHeader LocalArmazenamento;
        private System.Windows.Forms.ColumnHeader Distribuidor;
        private System.Windows.Forms.ColumnHeader Status;
        private System.Windows.Forms.PictureBox icone_voltar;
        private System.Windows.Forms.PictureBox icone_atualizar;
        private System.Windows.Forms.Button botao_editar;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}