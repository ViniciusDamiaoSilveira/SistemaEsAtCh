﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Admiministrador
{
    public partial class TelaChamadosInicial : Form
    {
        public TelaChamadosInicial()
        {
            InitializeComponent();
        }

        private void Botao_abertos_Click(object sender, EventArgs e)
        {
            TelaChamadosAberto telaabertos = new TelaChamadosAberto();
            telaabertos.Show();
            this.Hide();
        }

        private void Botao_fechados_Click(object sender, EventArgs e)
        {
            TelaChamadosFechados telafechados = new TelaChamadosFechados();
            telafechados.Show();
            this.Hide();
        }

        private void TelaChamadosInicial_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void Icone_voltar_Click(object sender, EventArgs e)
        {
            TelaInicial telainicial = new TelaInicial();
            telainicial.Show();
            this.Hide();
        }
    }
}
