﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AplicativoDesktop
{
    public partial class Tela_Login_Usuario : Form
    {
        private Form1 form1;
        MySqlConnection conexao;
        string dados_conexao = "datasource=ESN509VMYSQL;username=aluno;password=Senai1234;database=atches";

        //Construtor para utilizar o Form1
        public Tela_Login_Usuario(Form1 form1)
        {
            InitializeComponent();
            this.form1 = form1;
        }
        
        private void botao_entrar_Click(object sender, EventArgs e)
        {
            conexao = new MySqlConnection(dados_conexao);
            //Try Catch para usar a conexão com o banco
            try
            {
                //Abrir a conexão
                conexao.Open();

                //Utilizar o comando para verificação do login do usuário
                MySqlCommand comando = new MySqlCommand("SELECT * FROM users WHERE cpf = @cpf AND senha = @senha ", conexao);
                comando.Parameters.AddWithValue("@cpf", txt_cpf.Text);
                comando.Parameters.AddWithValue("@senha", txt_senha.Text);

                //Verifica se existe no banco
                var resultado = comando.ExecuteScalar();

                if (resultado != null)
                {
                    Form1 paginaInicial = new Form1();
                    paginaInicial.Show();
                    this.Visible = false;
                } else
                {
                    MessageBox.Show("Usuário ou Senha inválidos", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex.Message);
            } finally
            {
                conexao.Close();
            }
        }
    }
}
