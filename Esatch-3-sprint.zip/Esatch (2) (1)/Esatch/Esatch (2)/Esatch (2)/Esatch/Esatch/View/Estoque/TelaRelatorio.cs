﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch.View.Estoque
{
    public partial class TelaRelatorio : Form
    {
        string cpf;
        public TelaRelatorio(string cpf)
        {
            this.cpf = cpf;
            InitializeComponent();
        }

        Controller.RelatorioController controlador = new Controller.RelatorioController();

        private void TelaRelatorio_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void icone_voltar_Click(object sender, EventArgs e)
        {
            TelaInicial telainicial = new TelaInicial(cpf);
            telainicial.Show();
            this.Hide();
        }

        private void botao_relatorio_Click(object sender, EventArgs e)
        {
            if(txt_departamento.Text == "" || txt_descri.Text == "" || txt_nome.Text == "")
            {
                MessageBox.Show("Por favor, preencha todos os campos.", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                controlador.EnviarRelatorioEstoque(txt_nome.Text, txt_departamento.Text, txt_descri.Text, cpf);
                MessageBox.Show("Relatório sobre o estoque enviado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TelaInicial telainicial = new TelaInicial(cpf);
                telainicial.Show();
                this.Hide();
            }
           
        }
    }
}
