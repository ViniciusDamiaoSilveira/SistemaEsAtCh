﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Esatch
{
    public partial class TelaSistemas : Form
    {
        string cpf;
        public TelaSistemas(string cpf) {
            this.cpf = cpf;
            InitializeComponent();
        }

        

        private void TelaSistemas_FormClosed(object sender, FormClosedEventArgs e) {
            Application.Exit();
        }

        private void entrarEstoques(object sender, EventArgs e) {
            View.Estoque.TelaInicial telainicial = new View.Estoque.TelaInicial(cpf);
            telainicial.Show();
            this.Hide();
        }
        private void entrarChamados(object sender, EventArgs e) {
            View.Chamado.TelaInicio telainicial = new View.Chamado.TelaInicio(cpf);
            telainicial.Show();
            this.Hide();
        }
        private void entrarAtivos(object sender, EventArgs e) {
            View.Ativo.TelaInicial telainicial = new View.Ativo.TelaInicial(cpf);
            telainicial.Show();
            this.Hide();
        }

        private void Icone_voltar_Click(object sender, EventArgs e)
        {
            Form1 telainicial = new Form1();
            telainicial.Show();
            this.Hide();
        }
    }
}
